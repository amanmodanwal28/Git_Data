/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import MarqueeWithBack from '../Component/MarqueeWithBack'
import Banner from '../Component/Banner'
import Footer from '../Component/Footer'
import '../Css/Tourist.css'
import useFetchDataWithIp from '../Api/useFetchDataWithIp';

const Tourist = () => {
  const [places, setPlaces] = useState([]);
  const navigate = useNavigate();
  const { serverIp } = useFetchDataWithIp();

  useEffect(() => {
    if (serverIp) {
      fetch(`${serverIp}/database/tourist.json`) // Fetching from the API
        .then((response) => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then((data) => {
          setPlaces(data); // Set the fetched data to state
        })
        .catch((error) => console.error('Error fetching data:', error));
    }
  }, [serverIp]);

  const baseUrl = 'src/content/img/' // Base URL for images

  const handleImageClick = (place) => {
    navigate(`/place/${place.name.toLowerCase().replace(/\s+/g, '-')}`, {
      state: place,
    })
  }

  return (
    <>
      <MarqueeWithBack />
      <Banner />
      <h1 className="tourist-heading" onContextMenu={(e) => e.preventDefault()}>
        Tourist Places
      </h1>

      <div
        className="tourist-container"
        onContextMenu={(e) => e.preventDefault()}
      >
        {places.map((place, index) => (
          <div
            key={place.name}
            className={`place-item ${index % 2 === 0 ? 'left' : 'right'}`}
          >
            <div className="DataTouristAllInfo">
              <h2
                className="place-title"
                onClick={() => handleImageClick(place)}
              >
                {place.name}
              </h2>
              <div className="DataTouristInfo">
                {index % 2 === 0 ? (
                  <>
                    <img
                      alt={`Image of ${place.name}`}
                      src={`${baseUrl}${place.image}`}
                      className="place-image"
                      onClick={() => handleImageClick(place)}
                      onContextMenu={(e) => e.preventDefault()}
                    />
                    <div className="place-content">
                      <p
                        className="place-description"
                        onClick={() => handleImageClick(place)}
                      >
                        {place.description}
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="place-content">
                      <p
                        className="place-description"
                        onClick={() => handleImageClick(place)}
                      >
                        {place.description}
                      </p>
                    </div>
                    <img
                      alt={`Image of ${place.name}`}
                      src={`${baseUrl}${place.image}`}
                      className="place-image"
                      onClick={() => handleImageClick(place)}
                      onContextMenu={(e) => e.preventDefault()}
                    />
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <Footer />
    </>
  )
}

export default Tourist