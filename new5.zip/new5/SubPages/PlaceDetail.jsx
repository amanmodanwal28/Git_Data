/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom';
import MarqueeWithBack from "../Component/MarqueeWithBack";
import Banner from "../Component/Banner";
import Footer from "../Component/Footer";
import '../Css/PlaceDetail.css';
import useFetchDataWithIp from '../Api/useFetchDataWithIp';
const baseUrl = 'src/content/img/' // Base URL for images



const PlaceDetail = () => {
  const location = useLocation();
  const [fileList, setFileList] = useState([]);
  const place = location.state; // Access the place data passed through state
  const { serverIp } = useFetchDataWithIp();


  useEffect(() => {
    if (serverIp) {
      Promise.all([
        fetch(`${serverIp}/movies`)
      ])
      .then(([moviesResponse]) => {
        return Promise.all([
          moviesResponse.json(),
        ]);
      })
      .then(([moviesData]) => {
        setFileList(moviesData);
      })
      .catch((error) => console.error('Error fetching files:', error));
    }
  }, [serverIp]);


console.log(`${place.image2}`)

  if (!place) {
    return <h2>No place data available.</h2>;
  }

  return (
    <>
      <MarqueeWithBack />
      <Banner />
      <div className="place-detail">
        <h1>{place.name}</h1>
        <img
          src={`${place.image}`}
          alt={place.name}
          className="place-detail-image"
          onContextMenu={(e) => e.preventDefault()}
        />
        
        <p
          className="place-description"
          dangerouslySetInnerHTML={{ __html: place.descriptionDetail }}
        />
      </div>
      <Footer />
    </>
  )
};

export default PlaceDetail;
