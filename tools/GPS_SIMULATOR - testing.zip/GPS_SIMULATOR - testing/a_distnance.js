////correct /////   with each stop wait 5second 
////////////////////////////////////////
function calculateDistance(x1, y1, z1, x2, y2, z2) {
  const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
  return Math.round(distance);
}

class ObjectMovement {
  constructor(objectName, coordinates) {
    this.objectName = objectName;
    this.coordinates = coordinates;
    this.currentIndex = 0;
  }
  
  start() {
    this.moveToNextCoordinate();
  }
  
  moveToNextCoordinate() {
    const [x, y, z] = this.coordinates[this.currentIndex];
    const nextIndex = this.currentIndex + 1;
    
    if (nextIndex < this.coordinates.length) {
      const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
      const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);
      
      this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
      this.currentIndex = nextIndex;
    } else {
      console.log(`${this.objectName} reached the final destination point`);
    }
  }
  
  moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
    const timeInSeconds = 10;
    const distanceInMeters = distance;
    const objectSpeed = distanceInMeters / timeInSeconds;
    let remainingTime = timeInSeconds;

    console.log(`${this.objectName} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})`);
    console.log(`The distance to the next point is ${distance} meters.`);
    console.log(`The speed to the next point is ${objectSpeed} m/s.`);

    const countdown = setInterval(() => {
      remainingTime--;
      console.log(`Remaining time: ${remainingTime} seconds`);

      if (remainingTime <= 0) {
        clearInterval(countdown);
        console.log(`${this.objectName} reached the point at (${nextX}, ${nextY}, ${nextZ})`);

        if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
          setTimeout(() => {
            this.moveToNextCoordinate();
          }, 5000);
        }
      }
    }, 1500);
  }
}

const coordinates = [
  [1181707, 5554765, 2893882],
  [1317570, 5753654, 2409289],
  [1462131, 5773099, 2276379],
  [1485106, 5768442, 2273355]
];

const object1 = new ObjectMovement('Object 1', coordinates);
object1.start();



//////.......,,,,,,,,,//////////////////////////////////////
////////////////////////////////.........,,,,,,///////////////
// const express = require('express');
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(
//     Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) + Math.pow(z2 - z1, 2)
//   );
//   return Math.round(distance);
// }
// class ObjectMovement {
//   constructor(objectName, coordinates, res) {
//     this.objectName = objectName;
//     this.coordinates = coordinates;
//     this.currentIndex = 0;
//     this.res = res;
//     this.intervalId = null;
//     this.timerId = null;
//   }
// start() {
//     this.moveToNextCoordinate();
//   }
//   moveToNextCoordinate() {
//     const [x, y, z] = this.coordinates[this.currentIndex];
//     const nextIndex = this.currentIndex + 1;
//     if (nextIndex < this.coordinates.length) {
//       const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
//       const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);
//       this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
//       this.currentIndex = nextIndex;
//     } else {
//       this.res.write(`${this.objectName} reached the final destination point`);
//       this.res.write('Final destination completed');
//       this.res.end();
//     }
//   }
//   moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
//     const timeInSeconds = 10;
//     const distanceInMeters = distance;
//     const objectSpeed = distanceInMeters / timeInSeconds;
//     let remainingTime = timeInSeconds;
//     this.res.write(`${this.objectName} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})<br>`);
//     this.res.write(`The distance to the next point is ${distance} meters.<br>`);
//     this.res.write(`The speed to the next point is ${objectSpeed} m/s.<br>`);
//     this.res.write(`Countdown: ${remainingTime}s `);
//     const moveObject = () => {
//       remainingTime--;
//       if (remainingTime >= 0) {
//         // this.res.write('\x1B[1A\x1B[2K');
//         this.res.write(`<br>`)
//         this.res.write(`Countdown: ${remainingTime}s `);
//         this.timerId = setTimeout(moveObject, 1000);
//       } else {
//         this.res.write(`\n${this.objectName} reached the point at (${nextX}, ${nextY}, ${nextZ})<br>`);
//         if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
//           setTimeout(() => {
//             this.moveToNextCoordinate();
//           }, 5000);
//         }
//       }
//     };
//     this.intervalId = setTimeout(moveObject, 1000);
//   }
//   cleanup() {
//     clearTimeout(this.intervalId);
//     clearTimeout(this.timerId);
//   }
// }
// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];
// const app = express();
// const port = 3000;
// app.get('/', (req, res) => {
//   res.write('<h1>Object Movement</h1>\n');
//   const object1 = new ObjectMovement('Object 1', coordinates, res);
//   object1.start();
// })
// app.listen(port, () => {
//   console.log(`Server is running on http://localhost:${port}`);
// });


/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
// const express = require('express');

// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(
//     Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) + Math.pow(z2 - z1, 2)
//   );
//   return Math.round(distance);
// }

// class ObjectMovement {
//   constructor(objectName, coordinates, res) {
//     this.objectName = objectName;
//     this.coordinates = coordinates;
//     this.currentIndex = 0;
//     this.res = res;
//   }

//   start() {
//     this.moveToNextCoordinate();
//   }

//   moveToNextCoordinate() {
//     const [x, y, z] = this.coordinates[this.currentIndex];
//     const nextIndex = this.currentIndex + 1;

//     if (nextIndex < this.coordinates.length) {
//       const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
//       const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);

//       this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
//       this.currentIndex = nextIndex;
//     } else {
//       this.res.write(`${this.objectName} reached the final destination point
// `);
//       this.res.write(`Final destination completed
// `);
//       this.res.end();
//     }
//   }

//   moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
//     const timeInSeconds = 10;
//     const distanceInMeters = distance;
//     const objectSpeed = distanceInMeters / timeInSeconds;
//     let remainingTime = timeInSeconds;

//     this.res.write(`${this.objectName} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})<br>`);
//     this.res.write(`The distance to the next point is ${distance} meters.<br>`);
//     this.res.write(`The speed to the next point is ${objectSpeed} m/s.<br>`);
//     this.res.write(`Countdown: `);

//     const countdown = setInterval(() => {
//       remainingTime--;

//       if (remainingTime >= 0) {
//         this.res.write(`${remainingTime}s `);
//       } else {
//         clearInterval(countdown);
//         this.res.write(`<br>${this.objectName} reached the point at (${nextX}, ${nextY}, ${nextZ})<br>`);

//         if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
//           setTimeout(() => {
//             this.moveToNextCoordinate();
//           }, 5000);
//         }
//       }
//     }, 1000);
//   }
// }

// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];

// const app = express();
// const port = 3000;

// app.get('/', (req, res) => {
//   res.write('<h1>Object Movement</h1>\n');

//   const object1 = new ObjectMovement('Object 1', coordinates, res);
//   object1.start();
// });

// app.listen(port, () => {
//   console.log(`Server is running on http://localhost:${port}`);
// });



// ////correct /////   with each stop wait 5second 
// ////////////////////////////////////////
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
//   return Math.round(distance);
// }

// class ObjectMovement {
//   constructor(objectName, coordinates) {
//     this.objectName = objectName;
//     this.coordinates = coordinates;
//     this.currentIndex = 0;
//   }
  
//   start() {
//     this.moveToNextCoordinate();
//   }
  
//   moveToNextCoordinate() {
//     const [x, y, z] = this.coordinates[this.currentIndex];
//     const nextIndex = this.currentIndex + 1;
    
//     if (nextIndex < this.coordinates.length) {
//       const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
//       const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);
      
//       this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
//       this.currentIndex = nextIndex;
//     } else {
//       console.log(`${this.objectName} reached the final destination point`);
//     }
//   }
  
//   moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
//     const timeInSeconds = 10;
//     const distanceInMeters = distance;
//     const objectSpeed = distanceInMeters / timeInSeconds;
//     let remainingTime = timeInSeconds;

//     console.log(`${this.objectName} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})`);
//     console.log(`The distance to the next point is ${distance} meters.`);
//     console.log(`The speed to the next point is ${objectSpeed} m/s.`);

//     const countdown = setInterval(() => {
//       remainingTime--;
//       console.log(`Remaining time: ${remainingTime} seconds`);

//       if (remainingTime <= 0) {
//         clearInterval(countdown);
//         console.log(`${this.objectName} reached the point at (${nextX}, ${nextY}, ${nextZ})`);

//         if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
//           setTimeout(() => {
//             this.moveToNextCoordinate();
//           }, 5000);
//         }
//       }
//     }, 1500);
//   }
// }

// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];

// const object1 = new ObjectMovement('Object 1', coordinates);
// object1.start();




// ///////////////////
// /////////some correction need 
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) + Math.pow(z2 - z1, 2));
//   return Math.round(distance);
// }

// class ObjectMovement {
//   constructor(name, coordinates) {
//     this.name = name;
//     this.coordinates = coordinates;
//     this.currentIndex = 0;
//   }

//   start() {
//     this.moveToNextCoordinate();
//   }

//   moveToNextCoordinate() {
//     if (this.currentIndex >= this.coordinates.length) {
//       console.log("Object movement completed!");
//       return;
//     }

//     const currentCoordinates = this.coordinates[this.currentIndex];
//     const [x1, y1, z1] = currentCoordinates;

//     const nextIndex = this.currentIndex + 1;
//     if (nextIndex < this.coordinates.length) {
//       const nextCoordinates = this.coordinates[nextIndex];
//       const [x2, y2, z2] = nextCoordinates;
//       const distance = calculateDistance(x1, y1, z1, x2, y2, z2);
//       const travelTime = 10000; // 10 seconds
//       const speed = distance / travelTime;
//       let progress = 0;

//       console.log(`Moving ${this.name} from ${currentCoordinates} to ${nextCoordinates}`);

//       const interval = setInterval(() => {
//         progress += speed;
//         console.log(`${this.name} at (${x1 + (x2 - x1) * progress / distance}, ${y1 + (y2 - y1) * progress / distance}, ${z1 + (z2 - z1) * progress / distance})`);

//         if (progress >= distance) {
//           clearInterval(interval);
//           setTimeout(() => {
//             this.currentIndex = nextIndex;
//             this.moveToNextCoordinate();
//           }, 5000); // 5 seconds delay at each coordinate
//         }
//       }, 1000); // Update position every 1 second
//     } else {
//       console.log("Object movement completed!");
//     }
//   }
// }

// // Example usage
// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];
// const object1 = new ObjectMovement("Object 1", coordinates);
// object1.start();





///////////////////
/////////some correction need 
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//     const distance = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) + Math.pow(z2 - z1, 2));
//     return Math.round(distance);
// }

// class ObjectMovement {
//     constructor(name, coordinates) {
//         this.name = name;
//         this.coordinates = coordinates;
//         this.currentIndex = 0;
//     }

//     start() {
//         this.moveToNextCoordinate();
//     }

//     moveToNextCoordinate() {
//         if (this.currentIndex >= this.coordinates.length) {
//             console.log("Object movement completed!");
//             return;
//         }

//         const currentCoordinates = this.coordinates[this.currentIndex];
//         const [x1, y1, z1] = currentCoordinates;

//         const nextIndex = this.currentIndex + 1;
//         if (nextIndex < this.coordinates.length) {
//             const nextCoordinates = this.coordinates[nextIndex];
//             const [x2, y2, z2] = nextCoordinates;
//             const distance = calculateDistance(x1, y1, z1, x2, y2, z2);
//             let progress = 0;

//             console.log(`Moving ${this.name} from ${currentCoordinates} to ${nextCoordinates}`);

//             const interval = setInterval(() => {
//                 progress++;
//                 console.log(`${this.name} at (${x1 + (x2 - x1) * progress / distance}, ${y1 + (y2 - y1) * progress / distance}, ${z1 + (z2 - z1) * progress / distance})`);
//                 if (progress >= distance) {
//                     clearInterval(interval);
//                     setTimeout(() => {
//                         this.currentIndex = nextIndex;
//                         this.moveToNextCoordinate();
//                     }, 5000);
//                 }
//             }, 1000);
//         } else {
//             console.log("Object movement completed!");
//         }
//     }
// }
// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];
// const object1 = new ObjectMovement('Object 1', coordinates);
// // Example usage
// // const object1 = new ObjectMovement("Object 1", [[0, 0, 0], [1, 1, 1], [2, 2, 2], [3, 3, 3]]);
// object1.start();







//////right/////////////////////
/////////////////////////////////////////////////////////////////

// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
//   return Math.round(distance);
// }
// class ObjectMovement {
//   constructor(objectName, coordinates) {
//     this.objectName = objectName;
//     this.coordinates = coordinates;
//     this.currentIndex = 0;
//   }
//   start() {
//     this.moveToNextCoordinate();
//   }
//   moveToNextCoordinate() {
//     const [x, y, z] = this.coordinates[this.currentIndex];
//     const nextIndex = this.currentIndex + 1;
//     if (nextIndex < this.coordinates.length) {
//       const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
//       const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);
//       this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
//       this.currentIndex = nextIndex;
//     } else {
//       console.log(`${this.objectName} reached the final destination point`);
//     }
//   }
//   moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
//     const timeInSeconds = 10;
//     const distanceInMeters = distance ;
//     const objectSpeed = distanceInMeters / timeInSeconds;
//     let remainingTime = timeInSeconds;

//     console.log(`${this.objectName} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})`);
//     console.log(`The distance to the next point is ${distance} meters.`);
//     console.log(`The speed to the next point is ${objectSpeed} m/s.`);
//     const countdown = setInterval(() => {
//       remainingTime--;
//       console.log(`Remaining time: ${remainingTime} seconds`);
//       if (remainingTime <= 0) {
//         clearInterval(countdown);
//         console.log(`${this.objectName} reached the point at (${nextX}, ${nextY}, ${nextZ})`);
//         if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
//           this.moveToNextCoordinate();
//         }
//       }
//     }, 1500);
//   }
// }
// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];
// const object1 = new ObjectMovement('Object 1', coordinates);
// object1.start();



//////right/////////////////////
/////////////////////////////////////////////////////////////////
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
//   return Math.round(distance);}
// function isObjectReached(objectName, x, y, z, distance) {
//   const timeInSeconds = 10; // Set the desired time in seconds
//   const distanceInMeters = distance; // converting distance from km to meters
//   const objectSpeed = distanceInMeters / timeInSeconds; // calculate the required speed
//   console.log(objectSpeed + "speed in per second")
//   let remainingTime = timeInSeconds;
//   const countdown = setInterval(() => {
//     console.log(`Remaining time: ${remainingTime} seconds`);
//     remainingTime--;
//     if (remainingTime <= 0) {
//       clearInterval(countdown);
//       console.log(`${objectName} reached the point at (${x}, ${y}, ${z})`);
//       // Move on to the next coordinate
//       const nextIndex = coordinates.findIndex(coordinate => coordinate[0] === x && coordinate[1] === y && coordinate[2] === z) + 1;
//       if (nextIndex !== coordinates.length) {
//         const nextX = coordinates[nextIndex][0];
//         const nextY = coordinates[nextIndex][1];
//         const nextZ = coordinates[nextIndex][2];
//         const nextDistance = calculateDistance(x, y, z, nextX, nextY, nextZ);
//         console.log(`The distance to the next point is ${nextDistance} meters.`);
//         isObjectReached(objectName, nextX, nextY, nextZ, nextDistance);
//       }
//     }
//   }, 1500);
// }
// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355],
//   // Add more sets of coordinates here
// ];
// const initialX = coordinates[0][0];
// const initialY = coordinates[0][1];
// const initialZ = coordinates[0][2];
// const initialDistance = calculateDistance(initialX, initialY, initialZ, coordinates[1][0], coordinates[1][1], coordinates[1][2]);
// isObjectReached('Object 1', initialX, initialY, initialZ, initialDistance);


/////??/
///////////////////
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.round(Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2 + (z2 - z1) ** 2));
//   return distance;
// }

// function calculateSpeed(distance) {
//   const timeInSeconds = 10; // Set the time in seconds
//   const distanceInKilometers = distance; // The distance is already in kilometers
//   const distanceInMeters = distanceInKilometers * 1000; // converting distance from km to meters
//   const speedInMetersPerSecond = distanceInMeters / timeInSeconds; // calculate the speed in meters per second

//   // Convert speed from meters per second to kilometers per hour
//   const speedInKilometersPerHour = speedInMetersPerSecond * 3.6;

//   return speedInKilometersPerHour;
// }

// // Example usage
// const x1 = 1462131;
// const y1 = 5773099;
// const z1 = 2276379;

// const x2 = 1485106;
// const y2 = 5768442;
// const z2 = 2273355;

// const distance = calculateDistance(x1, y1, z1, x2, y2, z2);
// const speed = calculateSpeed(distance);

// console.log(`The distance is ${distance} kilometers.`);
// console.log(`The required speed to travel the distance in 10 seconds is ${speed} kilometers per hour.`);



///////////////////////////////////////////////////////
/////  counting in 10second
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
//   return Math.round(distance);
// }

// function isObjectReached(objectName, x, y, z, distance) {
//   const timeInSeconds = 10; // Set the desired time in seconds
//   const distanceInMeters = distance ; // converting distance from km to meters
//   const objectSpeed = distanceInMeters / timeInSeconds; // calculate the required speed

//   let remainingTime = timeInSeconds;
//   const countdown = setInterval(() => {
//     console.log(`Remaining time: ${remainingTime} seconds`);
//     remainingTime--;

//     if (remainingTime <= 0) {
//       clearInterval(countdown);
//       console.log(`${objectName} reached the point at (${x}, ${y}, ${z})`);
//     }
//   }, 1000);
// }

// // Example usage
// const x1 = 1462131;
// const y1 = 5773099;
// const z1 = 2276379;

// const x2 = 1485106;
// const y2 = 5768442;
// const z2 = 2273355;

// const distance = calculateDistance(x1, y1, z1, x2, y2, z2);
// console.log(`The distance between the points is ${distance} meters.`);

// isObjectReached("aman", x2, y2, z2, distance);





//////////////////////////////////////////////////

// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   return Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
// }

// function isObjectReached(objectName, x, y, z, distance) {
//   const objectSpeed = 50; // in km/h
//   const distanceInMeters = distance * 1000; // converting distance from km to meters
//   const timeInSeconds = (distanceInMeters / objectSpeed) * 3600; // converting time from hours to seconds
  
//   let remainingTime = timeInSeconds;
//   const countdown = setInterval(() => {
//     console.log(`Remaining time: ${remainingTime} seconds`);
//     remainingTime--;
    
//     if (remainingTime <= 0) {
//       clearInterval(countdown);
//       console.log(`${objectName} reached the point at (${x}, ${y}, ${z})`);
//     }
//   }, 1000);
// }

// // Example usage
// const x1 = 1462131;
// const y1 = 5773099;
// const z1 = 2276379;

// const x2 = 1485106;
// const y2 = 5768442;
// const z2 = 2273355;

// const distance = calculateDistance(x1, y1, z1, x2, y2, z2);
// console.log(`The distance between the points is ${distance} meters.`);

// isObjectReached('aman', x2, y2, z2, distance);
