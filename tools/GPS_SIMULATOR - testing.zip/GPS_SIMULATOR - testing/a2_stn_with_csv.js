////finding stn with csv file and journey database and check user input exist or not ////////
//////////////////////////////////////
/////////////////////
/////////////////////////
////finding stn with csv file and journey database and check user input exist or not ////////
const csv = require('csv-parser');
const fs = require('fs');
const xml2js = require('xml2js');
const readline = require('readline');

const csvArray = [];
const xmlArray = [];

// Read the CSV file
const results = new Set();
let results1 = '';

fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
  .pipe(csv())
  .on('data', (data) => {
    Object.keys(data).forEach((key) => {
      results.add(key.replace(/[.?[\]]/g, ''));
    });
    Object.values(data).forEach((value) => {
      results.add(value.replace(/[.?[\]]/g, ''));
    });
  })
  .on('end', () => {
    results1 = [...results];
    console.log(results1);

    // Read the XML file
    fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
      if (err) {
        console.error(err);
        return;
      }

      xml2js.parseString(xmlData, (parseErr, journeyresult) => {
        if (parseErr) {
          console.error(parseErr);
          return;
        }

        const journey = journeyresult.JOURNEY.JNUM;

        journey.forEach((row) => {
          const journey_no = row._.trim().replace(/\r?\n|\r/g, '');
          const stn = row.STN;

          xmlArray.push({ journey_no, stn });
        });

        const rl = readline.createInterface({
          input: process.stdin,
          output: process.stdout
        });

        rl.question('Enter a number: ', (number) => {
          rl.close();

          if (results1.includes(number)) {
            const matchingResult = xmlArray.find((item) => item.journey_no === number);

            if (matchingResult) {
              const journeyStations = matchingResult.stn;
              const stnValues = journeyStations.map(station => station.split(',')[0]);
              console.log(stnValues);
            }
          } else {
            console.log('Journey not found');
          }
        });
      });
    });
  });




///////////////////////////////////////////////////////////////
//////////////////////////////,,,,,,,,,,,,,,,,,,,,,
////////////////////...............................
///////////////////////////////////////////
// const csv = require('csv-parser');
// const fs = require('fs');
// const xml2js = require('xml2js');
// const csvArray = [];
// const xmlArray = [];

// // Read the CSV file
// const results = new Set();
// let results1 = [];

// fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
//     .pipe(csv())
//     .on('data', (data) => {
//         Object.keys(data).forEach((key) => {
//             results.add(key.replace(/[.?[\]]/g, ''));
//         });
//         Object.values(data).forEach((value) => {
//             results.add(value.replace(/[.?[\]]/g, ''));
//         });
//     })
//     .on('end', () => {
//         results1 = [...results];
//         // console.log(results1);

//         // Read the XML file
//         fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
//             if (err) {
//                 console.error(err);
//                 return;
//             }
//             xml2js.parseString(xmlData, (parseErr, result) => {
//                 if (parseErr) {
//                     console.error(parseErr);
//                     return;
//                 }
//                 const xmlRows = result.JOURNEY.JNUM;

//                 xmlRows.forEach((row) => {
//                     const journey_no = row._.trim().replace(/\r?\n|\r/g, '');
//                     const stn = row.STN;
//                     xmlArray.push({ journey_no, stn });
//                     // console.log(journey_no);////this journey_no define the journey no. in xml file 
//                     // console.log(xmlArray)
//                     // Check if journey_no exists in results1
//                     if (results1.includes(journey_no)) {
//                         // Find the corresponding STN data
//                         const matchingResult = xmlArray.find((item) => item.journey_no === journey_no);
//                         // console.log(matchingResult)
//                         if (matchingResult) {
//                             // console.log('Matching Journey Number:', journey_no);
//                             // console.log('Matching STN Data:', matchingResult.stn);
//                             const journeyStations = matchingResult.stn
//                             const stnValues = journeyStations.map(station => station.split(',')[0]);
//                             console.log(stnValues)
//                         }
//                     }
//                 });
//             });
//         });
//     });



// /////////////////////////////////////////////////
// /////////////////////////////////////////////////
// ////////////////////////////////////////////
// const csv = require('csv-parser');
// const fs = require('fs');
// const xml2js = require('xml2js');
// const csvArray = [];
// const xmlArray = [];

// // Read the CSV file
// const results = new Set();
// let results1='';

// fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
//     .pipe(csv())
//     .on('data', (data) => {
//         Object.keys(data).forEach((key) => {
//             results.add(key.replace(/[.?[\]]/g, ''));
//         });
//         Object.values(data).forEach((value) => {
//             results.add(value.replace(/[.?[\]]/g, ''));
//         });
//     })
//     .on('end', () => {
//         results1 = [...results]
//         console.log(results1);

//         // Read the XML file
//         fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
//             if (err) {
//                 console.error(err);
//                 return;
//             }
//             xml2js.parseString(xmlData, (parseErr, result) => {
//                 if (parseErr) {
//                     console.error(parseErr);
//                     return;
//                 }
//                 const xmlRows = result.JOURNEY.JNUM;

//                 xmlRows.forEach((row) => {
//                     const journey_no = row._.trim().replace(/\r?\n|\r/g, '')
//                     xmlArray.push(row);
//                     console.log(journey_no)
//                 });
//             });
//         });
//     });



//////////////////////////////////////
//////////////////////////////////////            
// const csv = require('csv-parser');
// const fs = require('fs');
// const xml2js = require('xml2js');
// const csvArray = [];
// const xmlArray = [];
// // Read the CSV file
// const results = new Set();
// let results1='';
// fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
//     .pipe(csv())
//     .on('data', (data) => {
//         Object.keys(data).forEach((key) => {
//             results.add(key.replace(/[.?[\]]/g, ''));
//         });
//         Object.values(data).forEach((value) => {
//             results.add(value.replace(/[.?[\]]/g, ''));
//         });
//     })
//     .on('end', () => {
//         results1 = [...results]
//         console.log(results1);
//         // Read the XML file
//         fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
//             if (err) {
//                 console.error(err);
//                 return;
//             }
//             xml2js.parseString(xmlData, (parseErr, result) => {
//                 if (parseErr) {
//                     console.error(parseErr);
//                     return;
//                 }
//                 const xmlRows = result.JOURNEY.JNUM;
//                 xmlRows.forEach((row) => {
//                     const journey_no = row._.trim().replace(/\r?\n|\r/g, '')
//                     xmlArray.push(row);
//                     console.log(journey_no)
//                 });
//             });
//         });
//     });




//////////////////////
// const csv = require('csv-parser');
// const fs = require('fs');
// const xml2js = require('xml2js');

// const csvArray = [];
// const xmlArray = [];

// // Read the CSV file
// fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
//     .pipe(csv())
//     .on('data', (row) => {
//         csvArray.push(row);
//     })
//     .on('end', () => {
//         console.log(csvArray);
//         // console.log('CSV file successfully processed');
//     });

// // Read the XML file
// fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
//     if (err) {
//         console.error(err);
//         return;
//     }
//     xml2js.parseString(xmlData, (parseErr, result) => {
//         if (parseErr) {
//             console.error(parseErr);
//             return;
//         }
//         const xmlRows = result.JOURNEY.JNUM;
//         //   console.log(xmlRows)
//         xmlRows.forEach((row) => {
//             const journey_no = row._.trim().replace(/\r?\n|\r/g, '')
//             xmlArray.push(row);
//             console.log(journey_no)
//         });
//         // console.log(xmlArray);
//         // console.log('XML file successfully processed');
//     });
// });




// const fs = require('fs');
// const csv = require('csv-parser');

// const results = [];

// fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
//     .pipe(csv()).on('data', (data) => {
//         results.push(data);
//         console.log(data)
//     }).on('end', () => {
//         console.log(results);
//     });
////////////
// const csv = require('csv-parser');
// const fs = require('fs');

// const array = [];

// fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
//   .pipe(csv())
//   .on('data', (row) => {
//     array.push(row);
//   })
//   .on('end', () => {
//     console.log(array[0]);
//     console.log('CSV file successfully processed');
//   });
