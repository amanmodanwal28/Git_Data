const fs = require('fs');
const xml2js = require('xml2js');
fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database1.xml', (err, journeyData) => {
    if (err) throw err; // Handle error if the file cannot be read
    xml2js.parseString(journeyData, (err, journeyResult) => {
        if (err) throw err; // Handle error if the XML cannot be parsed
        const journeys = journeyResult.JOURNEY.JNUM;
        const stnArrays = [];
        journeys.forEach((journey) => {
            const Station_name = journey.TNAME_E
            console.log(Station_name)
            const journeyStations = journey.STN;
            const stnValues = journeyStations.map(station => station.split(',')[0]);
            stnArrays.push(stnValues);
            console.log(stnValues)
        });
    });
});


























//////////////;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
/////'''''''''''''''''''''''''''''''''''''
/////////////////////////////////////////////
// const fs = require('fs');
// const xml2js = require('xml2js');
// fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database1.xml', (err, journeyData) => {
//     if (err) throw err; // Handle error if the file cannot be read
//     xml2js.parseString(journeyData, (err, journeyResult) => {
//         if (err) throw err; // Handle error if the XML cannot be parsed
//         const journeys = journeyResult.JOURNEY.JNUM;
//         const stnArrays = [];
//         journeys.forEach((journey) => {
//             const Station_name = journey.TNAME_E
//             console.log(Station_name)
//             const journeyStations = journey.STN;
//             const stnValues = journeyStations.map(station => station.split(',')[0]);
//             stnArrays.push(stnValues);
//             console.log(stnValues)

//             function calculateDistance(x1, y1, z1, x2, y2, z2) {
//                 const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
//                 return Math.round(distance);
//             }
//             class ObjectMovement {
//                 constructor(objectName, coordinates) {
//                     this.objectName = objectName;
//                     this.coordinates = coordinates;
//                     this.currentIndex = 0;
//                 }
//                 start() {
//                     this.moveToNextCoordinate();
//                 }
//                 moveToNextCoordinate() {
//                     const [x, y, z] = this.coordinates[this.currentIndex];
//                     const nextIndex = this.currentIndex + 1;
//                     if (nextIndex < this.coordinates.length) {
//                         const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
//                         const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);
//                         this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
//                         this.currentIndex = nextIndex;
//                     } else {
//                         console.log(`${stnValues[this.currentIndex]} reached the final destination point`);
//                     }
//                 }
//                 moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
//                     const timeInSeconds = 10;
//                     const distanceInMeters = distance;
//                     const objectSpeed = distanceInMeters / timeInSeconds;
//                     let remainingTime = timeInSeconds;
//                     console.log(`${stnValues[this.currentIndex]} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})`);
//                     console.log(`The distance to the next point is ${distance} meters.`);
//                     console.log(`The speed to the next point is ${objectSpeed} m/s.`);
//                     const countdown = setInterval(() => {
//                         remainingTime--;
//                         console.log(`Remaining time: ${remainingTime} seconds`);
//                         if (remainingTime <= 0) {
//                             clearInterval(countdown);
//                             console.log(`${stnValues[this.currentIndex-1]} reached ${stnValues[this.currentIndex ]} at the point (${nextX}, ${nextY}, ${nextZ})`);
//                             if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
//                                 setTimeout(() => {
//                                     this.moveToNextCoordinate();
//                                 }, 5000);
//                             }
//                         }
//                     }, 1500);
//                 }
//             }
//             const coordinates = [
//                 [1181707, 5554765, 2893882],
//                 [1317570, 5753654, 2409289],
//                 [1462131, 5773099, 2276379],
//                 [1485106, 5768442, 2273355],
//                 [1485160, 5768422, 2273315]
//             ];         
//             const object1 = new ObjectMovement(stnValues, coordinates);
//             object1.start();
//         });
//     });
// });



