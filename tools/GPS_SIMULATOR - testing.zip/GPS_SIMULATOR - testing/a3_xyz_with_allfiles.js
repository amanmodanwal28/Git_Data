
////finding X Y Z wit csv and station and journey database.xml  also check with user input they exist or not .
////finding X Y Z wit csv and station and journey database.xml

//////////////////////////////////////////////////////////////////////////

const csv = require('csv-parser');
const fs = require('fs');
const xml2js = require('xml2js');
const readline = require('readline');

const xmlArray = [];

// Read the CSV file
const results = new Set();
let results1 = '';

fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
    .pipe(csv())
    .on('data', (all_journey) => {
        Object.keys(all_journey).forEach((key) => {
            results.add(key.replace(/[.?[\]]/g, ''));
        });
        Object.values(all_journey).forEach((value) => {
            results.add(value.replace(/[.?[\]]/g, ''));
        });
    })
    .on('end', () => {
        results1 = [...results];
        console.log(results1);
        // Read the XML file
        fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
            if (err) {
                console.error(err);
                return;
            }
            xml2js.parseString(xmlData, (parseErr, journeyResult) => {
                if (parseErr) {
                    console.error(parseErr);
                    return;
                }
                const journeys = journeyResult.JOURNEY.JNUM;
                journeys.forEach((row) => {
                    const journey_no = row._.trim().replace(/\r?\n|\r/g, '');
                    const stn = row.STN;
                    xmlArray.push({ journey_no, stn });
                });
                const rl = readline.createInterface({
                    input: process.stdin,
                    output: process.stdout
                });
                const stnArrays = [];
                rl.question('Enter a number: ', (number) => {
                    rl.close();
                    if (results1.includes(number)) {
                        const matchingResult = xmlArray.find((item) => item.journey_no === number);
                        if (matchingResult) {
                            const journeyStations = matchingResult.stn;
                            const stnValues = journeyStations.map(station => station.split(',')[0]);
                            // console.log(stnValues);
                            stnArrays.push(stnValues);
                            console.log(stnArrays)
                            fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, stationData) => {
                                if (err) throw err;
                                xml2js.parseString(stationData, (err, stationResult) => {
                                    if (err) throw err;
                                    // Get the 'STATIONS' values
                                    const stations = stationResult.STATIONS.SC;
                                    const xyzArrays = [];
                                    console.log(stnArrays)
                                    stnArrays.forEach((stnArray, index) => {
                                        const xyzValues = [];
                                        // Iterate through each station in stnArray
                                        stnArray.forEach((stationName) => {
                                            const station = stations.find(station => station._.trim().replace(/\r?\n|\r/g, '') === stationName);
                                            if (station) {
                                                const x = station.X[0];
                                                const y = station.Y[0];
                                                const z = station.Z[0];
                                                xyzValues.push([x, y, z]);
                                            }
                                        });
                                        xyzArrays.push(xyzValues);
                                        console.log(xyzValues)
                                        

                                    });// console.log(xyzArrays);
                                })
                            })
                        }
                    } else {
                        console.log('Journey not found');
                    }
                });
            });
        });
    });





////finding X Y Z wit csv and station and journey database.xml  also check with user input they exist or not .
////finding X Y Z wit csv and station and journey database.xml

//////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
// const csv = require('csv-parser');
// const fs = require('fs');
// const xml2js = require('xml2js');
// const readline = require('readline');

// const xmlArray = [];

// // Read the CSV file
// const results = new Set();
// let results1 = '';

// fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
//     .pipe(csv())
//     .on('data', (data) => {
//         Object.keys(data).forEach((key) => {
//             results.add(key.replace(/[.?[\]]/g, ''));
//         });
//         Object.values(data).forEach((value) => {
//             results.add(value.replace(/[.?[\]]/g, ''));
//         });
//     })
//     .on('end', () => {
//         results1 = [...results];
//         console.log(results1);
//         // Read the XML file
//         fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
//             if (err) {
//                 console.error(err);
//                 return;
//             }
//             xml2js.parseString(xmlData, (parseErr, journeyResult) => {
//                 if (parseErr) {
//                     console.error(parseErr);
//                     return;
//                 }
//                 const journeys = journeyResult.JOURNEY.JNUM;
//                 journeys.forEach((row) => {
//                     const journey_no = row._.trim().replace(/\r?\n|\r/g, '');
//                     const stn = row.STN;
//                     xmlArray.push({ journey_no, stn });
//                 });
//                 const rl = readline.createInterface({
//                     input: process.stdin,
//                     output: process.stdout
//                 });
//                 const stnArrays = [];
//                 rl.question('Enter a number: ', (number) => {
//                     rl.close();
//                     if (results1.includes(number)) {
//                         const matchingResult = xmlArray.find((item) => item.journey_no === number);
//                         if (matchingResult) {
//                             const journeyStations = matchingResult.stn;
//                             const stnValues = journeyStations.map(station => station.split(',')[0]);
//                             // console.log(stnValues);
//                             stnArrays.push(stnValues);
//                             console.log(stnArrays)
//                             fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, stationData) => {
//                                 if (err) throw err;
//                                 xml2js.parseString(stationData, (err, stationResult) => {
//                                     if (err) throw err;
//                                     // Get the 'STATIONS' values
//                                     const stations = stationResult.STATIONS.SC;
//                                     const xyzArrays = [];
//                                     console.log(stnArrays)
//                                     stnArrays.forEach((stnArray, index) => {
//                                         const xyzValues = [];
//                                         // Iterate through each station in stnArray
//                                         stnArray.forEach((stationName) => {
//                                             const station = stations.find(station => station._.trim().replace(/\r?\n|\r/g, '') === stationName);
//                                             if (station) {
//                                                 const x = station.X[0];
//                                                 const y = station.Y[0];
//                                                 const z = station.Z[0];
//                                                 xyzValues.push([x, y, z]);
//                                             }
//                                         });
//                                         xyzArrays.push(xyzValues);
//                                         console.log(xyzValues)
                                        

//                                     });// console.log(xyzArrays);
//                                 })
//                             })
//                         }
//                     } else {
//                         console.log('Journey not found');
//                     }
//                 });
//             });
//         });
//     });



//////////////////////////////////////////////////////////////////