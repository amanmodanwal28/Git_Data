const fs = require('fs');
const { parseString } = require('xml2js');

const filePath = 'C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml';

fs.readFile(filePath, 'utf-8', (err, data) => {
  if (err) {
    console.error('Error reading file:', err);
    return;
  }

  parseString(data, (err, result) => {
    if (err) {
      console.error('Error parsing XML:', err);
      return;
    }

      const stations = result.STATIONS.SC;
    const xyzValues = stations.map(station => ({
      x: station.X[0],
      y: station.Y[0],
      z: station.Z[0]
    }));

    console.log(xyzValues);
  });
});












// const x111xmlFile = fs.readFileSync('C:\Users\\PTCS\\Desktop\\test2\\station_database.xml', 'utf-8');
