function safelyConvertToNumber(value) {
    if (typeof value === 'string' || value === 'undefined') {
        // Remove spaces and attempt to convert to a number
        const numericValue = parseFloat(value.replace(/\s/g, ''))

        // Check if the conversion is successful
        if (!isNaN(numericValue)) {
            return numericValue
        }
    }

    // Return the original value if it couldn't be converted
    return value
}

let lat1 = 26.4290227011419
let long = 82.5404858837144
let alt = 92

latitude1 = safelyConvertToNumber(lat1)
longitude1 = safelyConvertToNumber(long)
altitude1 = safelyConvertToNumber(alt)

const a = 6378137.0
const b = 6356752.314140371
    // const e2 = 0.00669437999014 // Square of the first eccentricity
    // const b = a * (1 - e2) ** 0.5
const latrad = latitude1 * (Math.PI / 180)
const longrad = longitude1 * (Math.PI / 180)
const N = a / Math.sqrt(1 - (1 - (b / a) ** 2) * Math.sin(latrad) ** 2)
const x = Math.abs(
    Math.floor((N + altitude1) * Math.cos(latrad) * Math.cos(longrad))
)
const y = Math.abs(
    Math.floor((N + altitude1) * Math.cos(latrad) * Math.sin(longrad))
)
const z = Math.abs(
    Math.floor(((b / a) ** 2 * N + altitude1) * Math.sin(latrad))
)

console.log(x, y, z)