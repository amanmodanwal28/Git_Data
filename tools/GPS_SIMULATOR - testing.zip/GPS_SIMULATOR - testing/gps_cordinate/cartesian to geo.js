const a = 6378137.0 // Semi-major axis
const e2 = 0.00669437999014 // Square of the first eccentricity
const b = a * Math.sqrt(1 - e2)
const e_prime_sq = (a ** 2 - b ** 2) / b ** 2

function cartesianToGeodetic(X, Y, Z) {
    // Compute longitude
    const lon = Math.atan2(Y, X)

    // Compute hypotenuse
    const p = Math.sqrt(X ** 2 + Y ** 2)

    // Initial approximation of latitude using Bowring's method
    const theta = Math.atan2(Z * a, p * b)
    const sin_theta = Math.sin(theta)
    const cos_theta = Math.cos(theta)

    // Iterative process to compute latitude
    let lat = Math.atan2(Z + e_prime_sq * b * sin_theta ** 3, p - e2 * a * cos_theta ** 3)

    // Compute altitude
    const N = a / Math.sqrt(1 - e2 * Math.sin(lat) ** 2)
    const h = Math.ceil(p / Math.cos(lat) - N)

    // Convert from radians to degrees
    lat = lat * (180 / Math.PI)
    const lon_deg = lon * (180 / Math.PI)

    return {
        latitude: lat,
        longitude: lon_deg,
        altitude: h
    }
}

// Example usage
const X = 742006
const Y = 5667038
const Z = 2821745

const { latitude, longitude, altitude } = cartesianToGeodetic(X, Y, Z)
console.log(
    `Latitude: ${latitude}, Longitude: ${longitude}, Altitude: ${altitude} meters`
)


// Latitude: 54.999974985297996°, Longitude: 3.9999958932730384°, Altitude: 0.45663187839090824 meters
// Latitude: 54.99997498529799°, Longitude: 3.9999958932730393°, Altitude: 0.45663187745958567 meters
// 742006 5667038 2821745

// let lat1 = 26.4290227011419// let long = 82.5404858837144// let alt = 92
// Latitude: 26.429015643804487°, Longitude: 82.54048868938325°, Altitude: 91.45242785755545 meters
// Latitude: 26.429015643804487°, Longitude: 82.54048868938325°, Altitude: 91.45242785755545 meters