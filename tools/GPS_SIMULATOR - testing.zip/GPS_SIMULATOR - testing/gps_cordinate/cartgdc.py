import math

# WGS84 constants
a = 6378137.0  # Semi-major axis
e2 = 0.00669437999014  # Square of the first eccentricity
b = a * (1 - e2) ** 0.5
e_prime_sq = (a**2 - b**2) / b**2


def cartesian_to_geodetic(X, Y, Z):
    # Compute longitude
    lon = math.atan2(Y, X)

    # Compute hypotenuse
    p = math.sqrt(X**2 + Y**2)

    # Initial approximation of latitude using Bowring's method
    theta = math.atan2(Z * a, p * b)
    sin_theta = math.sin(theta)
    cos_theta = math.cos(theta)

    # Iterative process to compute latitude
    lat = math.atan2(Z + e_prime_sq * b * sin_theta**3, p - e2 * a * cos_theta**3)

    # Compute altitude
    N = a / math.sqrt(1 - e2 * math.sin(lat)**2)
    h = p / math.cos(lat) - N

    # Convert from radians to degrees
    lat = math.degrees(lat)
    lon = math.degrees(lon)

    return lat, lon, h

# Example usage
X = 3657664.44
Y = 255768.55
Z = 5201382.30

lat, lon, alt = cartesian_to_geodetic(X, Y, Z)
print(f"Latitude: {lat}°, Longitude: {lon}°, Altitude: {alt} meters")

