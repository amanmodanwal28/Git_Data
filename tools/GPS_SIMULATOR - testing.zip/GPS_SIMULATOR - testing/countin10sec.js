function calculateDistance(x1, y1, z1, x2, y2, z2) {
  const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
  return Math.round(distance);
}

function isObjectReached(objectName, x, y, z, distance) {
  const timeInSeconds = 10; // Set the desired time in seconds
  const distanceInMeters = distance ; // converting distance from km to meters
  const objectSpeed = distanceInMeters / timeInSeconds; // calculate the required speed
console.log(objectSpeed+"speed in per second")
  let remainingTime = timeInSeconds;
  const countdown = setInterval(() => {
    console.log(`Remaining time: ${remainingTime} seconds`);
    remainingTime--;

    if (remainingTime <= 0) {
      clearInterval(countdown);
      console.log(`${objectName} reached the point at (${x}, ${y}, ${z})`);
    }
  }, 1000);
}

// Example usage
const x1 = 1462131;
const y1 = 5773099;
const z1 = 2276379;

const x2 = 1485106;
const y2 = 5768442;
const z2 = 2273355;

const distance = calculateDistance(x1, y1, z1, x2, y2, z2);
console.log(`The distance between the points is ${distance} meters.`);

isObjectReached("aman", x2, y2, z2, distance);
