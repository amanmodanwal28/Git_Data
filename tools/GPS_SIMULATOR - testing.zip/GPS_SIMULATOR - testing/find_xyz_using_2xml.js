const fs = require('fs');
const xml2js = require('xml2js');
let XYZ=[]
// Read the first XML file to get the 'JNUM' values
fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', (err, journeyData) => {
  if (err) throw err;
  // Read the second XML file to get the 'SC' values
  fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, stationData) => {
    if (err) throw err;
    // Parse the XML data for 'JOURNEY'
    xml2js.parseString(journeyData, (err, journeyResult) => {
      if (err) throw err;
      // Parse the XML data for 'STATIONS'
      xml2js.parseString(stationData, (err, stationResult) => {
        if (err) throw err;
        // Get the 'JNUM' values
        const journeys = journeyResult.JOURNEY.JNUM;
        // Get the 'STATIONS' values
        const stations = stationResult.STATIONS.SC;
        // Create an array to store the stn values for each journey
        const stnArrays = [];
        // Iterate through each 'JNUM' value
        journeys.forEach((journey) => {
          const journeyStations = journey.STN;
          const stnValues = journeyStations.map(station => station.split(',')[0]);
          stnArrays.push(stnValues);
        });
        console.log(stnArrays)
        // Iterate through each stnArray
        stnArrays.forEach((stnArray, index) => {
          // Iterate through each station in stnArray
          stnArray.forEach((stationName) => {
            const station = stations.find(station => station._.trim().replace(/\r?\n|\r/g, '') === stationName);
            if (station) {
              const name = station._.trim().replace(/\r?\n|\r/g, '');
              const x = station.X;
              const y = station.Y;
              const z = station.Z;
              console.log(`Name: ${name}`);
              console.log(`X: ${x}`);
              console.log(`Y: ${y}`);
              console.log(`Z: ${z}`);
              console.log('---------------');
            }
          });
        });
      });
    });
  });
});