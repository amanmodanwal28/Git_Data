const csv = require('csv-parser');
const fs = require('fs');
const xml2js = require('xml2js');
const readline = require('readline');

const csvArray = [];
const xmlArray = [];

// Read the CSV file
const results = new Set();
let results1 = '';

fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
  .pipe(csv())
  .on('data', (data) => {
    Object.keys(data).forEach((key) => {
      results.add(key.replace(/[.?[\]]/g, ''));
    });
    Object.values(data).forEach((value) => {
      results.add(value.replace(/[.?[\]]/g, ''));
    });
  })
  .on('end', () => {
    results1 = [...results];
    console.log(results1);

    // Read the XML file
    fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
      if (err) {
        console.error(err);
        return;
      }

      xml2js.parseString(xmlData, (parseErr, result) => {
        if (parseErr) {
          console.error(parseErr);
          return;
        }

        const xmlRows = result.JOURNEY.JNUM;

        xmlRows.forEach((row) => {
          const journey_no = row._.trim().replace(/\r?\n|\r/g, '');
          const stn = row.STN;

          xmlArray.push({ journey_no, stn });
        });

        const rl = readline.createInterface({
          input: process.stdin,
          output: process.stdout
        });

        rl.question('Enter a number: ', (number) => {
          rl.close();

          if (results1.includes(number)) {
            const matchingResult = xmlArray.find((item) => item.journey_no === number);

            if (matchingResult) {
              const journeyStations = matchingResult.stn;
              const stnValues = journeyStations.map(station => station.split(',')[0]);
              console.log(stnValues);
            }
          } else {
            console.log('Journey not found');
          }
        });
      });
    });
  });