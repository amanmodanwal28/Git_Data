/////this one is used for server output
////////////////////////////////////////////
// const express = require('express');

// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(
//     Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) + Math.pow(z2 - z1, 2)
//   );
//   return Math.round(distance);
// }

// class ObjectMovement {
//   constructor(objectName, coordinates, res) {
//     this.objectName = objectName;
//     this.coordinates = coordinates;
//     this.currentIndex = 0;
//     this.res = res;
//     this.intervalId = null;
//     this.timerId = null;
//   }

//   start() {
//     this.moveToNextCoordinate();
//   }

//   moveToNextCoordinate() {
//     const [x, y, z] = this.coordinates[this.currentIndex];
//     const nextIndex = this.currentIndex + 1;

//     if (nextIndex < this.coordinates.length) {
//       const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
//       const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);

//       this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
//       this.currentIndex = nextIndex;
//     } else {
//       this.res.write(`${this.objectName} reached the final destination point`);
//       this.res.write('Final destination completed');
//       this.res.end();
//     }
//   }

//   moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
//     const timeInSeconds = 10;
//     const distanceInMeters = distance;
//     const objectSpeed = distanceInMeters / timeInSeconds;
//     let remainingTime = timeInSeconds;

//     this.res.write(`${this.objectName} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})<br>`);
//     this.res.write(`The distance to the next point is ${distance} meters.<br>`);
//     this.res.write(`The speed to the next point is ${objectSpeed} m/s.<br>`);
//     this.res.write(`Countdown: ${remainingTime}s `);

//     const moveObject = () => {
//       remainingTime--;

//       if (remainingTime >= 0) {
//         // this.res.write('\x1B[1A\x1B[2K');
//         this.res.write(`<br>`)
//         this.res.write(`Countdown: ${remainingTime}s `);

//         this.timerId = setTimeout(moveObject, 1000);
//       } else {
//         this.res.write(`\n${this.objectName} reached the point at (${nextX}, ${nextY}, ${nextZ})<br>`);

//         if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
//           setTimeout(() => {
//             this.moveToNextCoordinate();
//           }, 5000);
//         }
//       }
//     };

//     this.intervalId = setTimeout(moveObject, 1000);
//   }

//   cleanup() {
//     clearTimeout(this.intervalId);
//     clearTimeout(this.timerId);
//   }
// }

// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];

// const app = express();
// const port = 3000;

// app.get('/', (req, res) => {
//   res.write('<h1>Object Movement</h1>\n');

//   const object1 = new ObjectMovement('Object 1', coordinates, res);
//   object1.start();
// })
// app.listen(port, () => {
//   console.log(`Server is running on http://localhost:${port}`);
// });






///////////////////////////////////////////
/////////////////////////////////
////////////////////////////////
function calculateDistance(x1, y1, z1, x2, y2, z2) {
  const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
  return Math.round(distance);
}

class ObjectMovement {
  constructor(objectName, coordinates) {
    this.objectName = objectName;
    this.coordinates = coordinates;
    this.currentIndex = 0;
  }
  
  start() {
    this.moveToNextCoordinate();
  }
  
  moveToNextCoordinate() {
    const [x, y, z] = this.coordinates[this.currentIndex];
    const nextIndex = this.currentIndex + 1;
    
    if (nextIndex < this.coordinates.length) {
      const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
      const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);
      
      this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
      this.currentIndex = nextIndex;
    } else {
      console.log(`${this.objectName} reached the final destination point`);
    }
  }
  
  moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
    const timeInSeconds = 10;
    const distanceInMeters = distance;
    const objectSpeed = distanceInMeters / timeInSeconds;
    let remainingTime = timeInSeconds;

    console.log(`${this.objectName} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})`);
    console.log(`The distance to the next point is ${distance} meters.`);
    console.log(`The speed to the next point is ${objectSpeed} m/s.`);

    const countdown = setInterval(() => {
      remainingTime--;
      console.log(`Remaining time: ${remainingTime} seconds`);

      if (remainingTime <= 0) {
        clearInterval(countdown);
        console.log(`${this.objectName} reached the point at (${nextX}, ${nextY}, ${nextZ})`);

        if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
          setTimeout(() => {
            this.moveToNextCoordinate();
          }, 5000);
        }
      }
    }, 1500);
  }
}

// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];
const coordinates =[
  
    [ '1172640', '5604590', '2800705' ],
    [ '1181707', '5554765', '2893882' ],
    [ '1208811', '5531992', '2925922' ],
    [ '1236608', '5466826', '3034116' ],
    [ '0967236', '5679808', '2726969' ],
    [ '0967236', '5679808', '2726969' ],
    [ '1236608', '5466826', '3034116' ],
    [ '1208811', '5531992', '2925922' ],
    [ '1181707', '5554765', '2893882' ],
    [ '1172640', '5604590', '2800705' ]
  
]
const object1 = new ObjectMovement('Object 1', coordinates);
object1.start();



////correct   ///////////////
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
//   return Math.round(distance);
// }
// class ObjectMovement {
//   constructor(objectName, coordinates) {
//     this.objectName = objectName;
//     this.coordinates = coordinates;
//     this.currentIndex = 0;
//   }
//   start() {
//     this.moveToNextCoordinate();
//   }
//   moveToNextCoordinate() {
//     const [x, y, z] = this.coordinates[this.currentIndex];
//     const nextIndex = this.currentIndex + 1;
//     if (nextIndex < this.coordinates.length) {
//       const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
//       const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);
//       this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
//       this.currentIndex = nextIndex;
//     } else {
//       console.log(`${this.objectName} reached the final destination point`);
//     }
//   }
//   moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
//     const timeInSeconds = 10;
//     const distanceInMeters = distance ;
//     const objectSpeed = distanceInMeters / timeInSeconds;
//     let remainingTime = timeInSeconds;

//     console.log(`${this.objectName} is moving from (${x}, ${y}, ${z}) to (${nextX}, ${nextY}, ${nextZ})`);
//     console.log(`The distance to the next point is ${distance} meters.`);
//     console.log(`The speed to the next point is ${objectSpeed} m/s.`);
//     const countdown = setInterval(() => {
//       remainingTime--;
//       console.log(`Remaining time: ${remainingTime} seconds`);
//       if (remainingTime <= 0) {
//         clearInterval(countdown);
//         console.log(`${this.objectName} reached the point at (${nextX}, ${nextY}, ${nextZ})`);
//         if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
//           this.moveToNextCoordinate();
//         }
//       }
//     }, 1500);
//   }
// }
// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355]
// ];
// const object1 = new ObjectMovement('Object 1', coordinates);
// object1.start();






//////correct/////////////////////////////////////////
/////////////////////////////////////////////////////////////
// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
//   return Math.round(distance);
// }

// function isObjectReached(objectName, x, y, z, distance) {
//   const timeInSeconds = 10; // Set the desired time in seconds
//   const distanceInMeters = distance; // converting distance from km to meters
//   const objectSpeed = distanceInMeters / timeInSeconds; // calculate the required speed
//   console.log(objectSpeed + "speed in per second")

//   let remainingTime = timeInSeconds;
//   const countdown = setInterval(() => {
//     console.log(`Remaining time: ${remainingTime} seconds`);
//     remainingTime--;

//     if (remainingTime <= 0) {
//       clearInterval(countdown);
//       console.log(`${objectName} reached the point at (${x}, ${y}, ${z})`);

//       // Move on to the next coordinate
//       const nextIndex = coordinates.findIndex(coordinate => coordinate[0] === x && coordinate[1] === y && coordinate[2] === z) + 1;
//       if (nextIndex !== coordinates.length) {
//         const nextX = coordinates[nextIndex][0];
//         const nextY = coordinates[nextIndex][1];
//         const nextZ = coordinates[nextIndex][2];
//         const nextDistance = calculateDistance(x, y, z, nextX, nextY, nextZ);
//         console.log(`The distance to the next point is ${nextDistance} meters.`);

//         isObjectReached(objectName, nextX, nextY, nextZ, nextDistance);
//       }
//     }
//   }, 1000);
// }

// // Example usage
// // const coordinates = [
// //   [1462131, 5773099, 2276379],
// //   [1485106, 5768442, 2273355],
// //   // Add more sets of coordinates here
// // ];
// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355],
//   // Add more sets of coordinates here
// ];

// const initialX = coordinates[0][0];
// const initialY = coordinates[0][1];
// const initialZ = coordinates[0][2];
// const initialDistance = calculateDistance(initialX, initialY, initialZ, coordinates[1][0], coordinates[1][1], coordinates[1][2]);

// isObjectReached('Object 1', initialX, initialY, initialZ, initialDistance);













// function calculateDistance(x1, y1, z1, x2, y2, z2) {
//   const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
//   return Math.round(distance);
// }

// function isObjectReached(objectName, x, y, z, distance) {
//   const timeInSeconds = 10; // Set the desired time in seconds
//   const distanceInMeters = distance; // converting distance from km to meters
//   const objectSpeed = distanceInMeters / timeInSeconds; // calculate the required speed
//   console.log(objectSpeed + "speed in per second")

//   let remainingTime = timeInSeconds;
//   const countdown = setInterval(() => {
//     console.log(`Remaining time: ${remainingTime} seconds`);
//     remainingTime--;

//     if (remainingTime <= 0) {
//       clearInterval(countdown);
//       console.log(`${objectName} reached the point at (${x}, ${y}, ${z})`);
//     }
//   }, 1000);
// }

// // Example usage
// const coordinates = [
//   [1181707, 5554765, 2893882],
//   [1317570, 5753654, 2409289],
//   [1462131, 5773099, 2276379],
//   [1485106, 5768442, 2273355],
//   // Add more sets of coordinates here
// ];

// for (let i = 0; i < coordinates.length - 1; i++) {
//   const x1 = coordinates[i][0];
//   const y1 = coordinates[i][1];
//   const z1 = coordinates[i][2];

//   const x2 = coordinates[i + 1][0];
//   const y2 = coordinates[i + 1][1];
//   const z2 = coordinates[i + 1][2];

//   const distance = calculateDistance(x1, y1, z1, x2, y2, z2);
//   console.log(`The distance between the points is ${distance} meters.`);

//   isObjectReached(`Object ${i + 1}`, x2, y2, z2, distance);
// }

