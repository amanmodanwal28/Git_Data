const csv = require('csv-parser');
const fs = require('fs');
const xml2js = require('xml2js');
const readline = require('readline');
const xmlArray = [];
// Read the CSV file
const results = new Set();
let results1 = '';

fs.createReadStream('C:\\Users\\PTCS\\Desktop\\test2\\all_journey.csv')
    .pipe(csv())
    .on('data', (all_journey) => {
        Object.keys(all_journey).forEach((key) => {
            results.add(key.replace(/[.?[\]]/g, ''));
        });
        Object.values(all_journey).forEach((value) => {
            results.add(value.replace(/[.?[\]]/g, ''));
        });
    })
    .on('end', () => {
        results1 = [...results];
        console.log(results1);
        // Read the XML file
        fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', 'utf-8', (err, xmlData) => {
            if (err) {
                console.error(err);
                return;
            }
            xml2js.parseString(xmlData, (parseErr, journeyResult) => {
                if (parseErr) {
                    console.error(parseErr);
                    return;
                }
                const journeys = journeyResult.JOURNEY.JNUM;
                journeys.forEach((row) => {
                    const journey_no = row._.trim().replace(/\r?\n|\r/g, '');
                    const stn = row.STN;
                    xmlArray.push({ journey_no, stn });
                });
                const rl = readline.createInterface({
                    input: process.stdin,
                    output: process.stdout
                });
                const stnArrays = [];
                rl.question('Enter a number: ', (number) => {
                    rl.close();
                    if (results1.includes(number)) {
                        const matchingResult = xmlArray.find((item) => item.journey_no === number);
                        if (matchingResult) {
                            const journeyStations = matchingResult.stn;
                            const stnValues = journeyStations.map(station => station.split(',')[0]);
                            // console.log(stnValues);
                            stnArrays.push(stnValues);
                            console.log(stnArrays)
                            fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, stationData) => {
                                if (err) throw err;
                                xml2js.parseString(stationData, (err, stationResult) => {
                                    if (err) throw err;
                                    // Get the 'STATIONS' values
                                    const stations = stationResult.STATIONS.SC;
                                    const xyzArrays = [];
                                    // console.log(stnArrays)
                                    stnArrays.forEach((stnArray, index) => {
                                        const xyzValues = [];
                                        // Iterate through each station in stnArray
                                        stnArray.forEach((stationName) => {
                                            const station = stations.find(station => station._.trim().replace(/\r?\n|\r/g, '') === stationName);
                                            if (station) {
                                                const x = station.X[0];
                                                const y = station.Y[0];
                                                const z = station.Z[0];
                                                xyzValues.push([x, y, z]);
                                            }
                                        });
                                        xyzArrays.push(xyzValues);
                                        // console.log(xyzValues)

                                        function calculateDistance(x1, y1, z1, x2, y2, z2) {
                                            const distance = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
                                            return Math.round(distance);
                                        } class ObjectMovement {
                                            constructor(objectName, coordinates) {
                                                this.objectName = objectName;
                                                this.coordinates = coordinates;
                                                this.currentIndex = 0;
                                            }
                                            start() {
                                                this.moveToNextCoordinate();
                                            }
                                            moveToNextCoordinate() {
                                                const [x, y, z] = this.coordinates[this.currentIndex];
                                                const nextIndex = this.currentIndex + 1;

                                                if (nextIndex < this.coordinates.length) {
                                                    const [nextX, nextY, nextZ] = this.coordinates[nextIndex];
                                                    const distance = calculateDistance(x, y, z, nextX, nextY, nextZ);

                                                    this.moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ);
                                                    this.currentIndex = nextIndex;
                                                } else {
                                                    console.log(`${stnValues[this.currentIndex - 1]} reached the final Station .`);
                                                    console.log(`.........................................................................`);
                                                    console.log(`Present station is ${stnValues[this.currentIndex]} Station .`);
                                                }
                                            }

                                            moveObjectToCoordinates(x, y, z, distance, nextX, nextY, nextZ) {
                                                const timeInSeconds = 10;
                                                const distanceInMeters = distance;
                                                const objectSpeed = distanceInMeters / timeInSeconds;
                                                let remainingTime = timeInSeconds;

                                                console.log(`This ${stnValues[this.currentIndex]} Station is moving from ${stnValues[this.currentIndex]} Station  to ${stnValues[this.currentIndex+1]} Station`);
                                                console.log(`                                                                        `);
                                                console.log(`Present Station point is  (${x}, ${y}, ${z}) Next Station point is (${nextX}, ${nextY}, ${nextZ}) .`);
                                                console.log(`                                                                        `);
                                                console.log(`The distance to the next Station is ${distance} meters.`);
                                                console.log(`                                                                        `);
                                                console.log(`The speed of the Train is ${objectSpeed} m/s.`);
                                                console.log(`                                                                        `);
                                                const countdown = setInterval(() => {
                                                    remainingTime--;
                                                    console.log(`Remaining time: ${remainingTime} seconds`);

                                                    if (remainingTime <= 0) {
                                                        clearInterval(countdown);
                                                        console.log(`                                                                        `);
                                                        console.log(`${stnValues[this.currentIndex - 1]} Station reached the point at (${nextX}, ${nextY}, ${nextZ})`);
                                                        console.log(`                                                                        `);


                                                        if (nextX !== undefined && nextY !== undefined && nextZ !== undefined) {
                                                            setTimeout(() => {
                                                                this.moveToNextCoordinate();
                                                            }, 5000);
                                                        }
                                                    }
                                                }, 1500);
                                            }
                                        }
                                        // const coordinates = [
                                        //     [1181707, 5554765, 2893882],
                                        //     [1317570, 5753654, 2409289],
                                        //     [1462131, 5773099, 2276379],
                                        //     [1485106, 5768442, 2273355]
                                        // ];

                                        const coordinates = xyzValues;

                                        const object1 = new ObjectMovement(stnValues, coordinates);
                                        object1.start();
                                        

                                    });// console.log(xyzArrays);
                                })
                            })
                        }
                    } else {
                        console.log('Journey not found');
                    }
                });
            });
        });   
    });
