const fs = require('fs');
const xml2js = require('xml2js');
// Read the first XML file to get the 'JNUM' values
fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', (err, journeyData) => {
  if (err) throw err;
  // Read the second XML file to get the 'SC' values
  fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, stationData) => {
    if (err) throw err;
    // Parse the XML data for 'JOURNEY'
    xml2js.parseString(journeyData, (err, journeyResult) => {
      if (err) throw err;
      // Parse the XML data for 'STATIONS'
      xml2js.parseString(stationData, (err, stationResult) => {
        if (err) throw err;
        // Get the 'JNUM' values
        const journeys = journeyResult.JOURNEY.JNUM;
        // Get the 'STATIONS' values
        const stations = stationResult.STATIONS.SC;
        // Create an array to store the stn values for each journey
        const stnArrays = [];
        // Iterate through each 'JNUM' value
        // console.log(journeys)
        journeys.forEach((journey) => {
          const journeyStations = journey.STN;
          const stnValues = journeyStations.map(station => station.split(',')[0]);
          stnArrays.push(stnValues);
          // console.log(stnValues)
        });
        // Create an array to store the x, y, and z values
        const xyzArrays = [];
        // console.log(stnArrays)
        // Iterate through each stnArray
        stnArrays.forEach((stnArray, index) => {
          const xyzValues = [];

          // Iterate through each station in stnArray
          stnArray.forEach((stationName) => {
            const station = stations.find(station => station._.trim().replace(/\r?\n|\r/g, '') === stationName);

            if (station) {
              const x = station.X[0];
              const y = station.Y[0];
              const z = station.Z[0];
              xyzValues.push([x, y, z]);
            }
          });

          xyzArrays.push(xyzValues);
          console.log(xyzValues)
        });

        // Use the xyzArrays outside the loop
        // console.log(xyzArrays);
        // Perform further operations with the xyzArrays here
      });
    });
  });
});


///////////.....,,,,,,,,,,////////////
//////////////////////////////
// const fs = require('fs');
// const xml2js = require('xml2js');

// // Read the first XML file to get the 'JNUM' values
// fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', (err, journeyData) => {
//   if (err) throw err;

//   // Read the second XML file to get the 'SC' values
//   fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, stationData) => {
//     if (err) throw err;

//     // Parse the XML data for 'JOURNEY'
//     xml2js.parseString(journeyData, (err, journeyResult) => {
//       if (err) throw err;

//       // Parse the XML data for 'STATIONS'
//       xml2js.parseString(stationData, (err, stationResult) => {
//         if (err) throw err;

//         // Get the 'JNUM' values
//         const journeys = journeyResult.JOURNEY.JNUM;

//         // Get the 'STATIONS' values
//         const stations = stationResult.STATIONS.SC;

//         // Create an array to store the stn values for each journey
//         const stnArrays = [];

//         // Iterate through each 'JNUM' value
//         journeys.forEach((journey) => {
//           const journeyStations = journey.STN;
//           const stnValues = journeyStations.map(station => station.split(',')[0]);
//           stnArrays.push(stnValues);
//         });

//         // Create an array to store the x, y, and z values
//         const xyzArrays = [];

//         // Iterate through each stnArray
//         stnArrays.forEach((stnArray, index) => {
//           const xyzValues = [];

//           // Iterate through each station in stnArray
//           stnArray.forEach((stationName) => {
//             const station = stations.find(station => station._.trim().replace(/\r?\n|\r/g, '') === stationName);

//             if (station) {
//               const x = station.X[0];
//               const y = station.Y[0];
//               const z = station.Z[0];

//               xyzValues.push([ x, y, z ]);
//             }
//           });
//           console.log(xyzValues);
//           // xyzArrays.push(xyzValues);
//         });

//         // Use the xyzArrays outside the loop
//         // console.log(xyzArrays);
//       });
//     });
//   });
// });


/////////////,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
////////////////,,,,,,,,,,,,,,,,,,////////////........................
///////////////////////////////////////
// const fs = require('fs');
// const xml2js = require('xml2js');
// let XYZ=[]
// // Read the first XML file to get the 'JNUM' values
// fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', (err, journeyData) => {
//   if (err) throw err;
//   // Read the second XML file to get the 'SC' values
//   fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, stationData) => {
//     if (err) throw err;
//     // Parse the XML data for 'JOURNEY'
//     xml2js.parseString(journeyData, (err, journeyResult) => {
//       if (err) throw err;
//       // Parse the XML data for 'STATIONS'
//       xml2js.parseString(stationData, (err, stationResult) => {
//         if (err) throw err;
//         // Get the 'JNUM' values
//         const journeys = journeyResult.JOURNEY.JNUM;
//         // Get the 'STATIONS' values
//         const stations = stationResult.STATIONS.SC;
//         // Create an array to store the stn values for each journey
//         const stnArrays = [];
//         // Iterate through each 'JNUM' value
//         journeys.forEach((journey) => {
//           const journeyStations = journey.STN;
//           const stnValues = journeyStations.map(station => station.split(',')[0]);
//           stnArrays.push(stnValues);
//         });
//         console.log(stnArrays)
//         // Iterate through each stnArray
//         stnArrays.forEach((stnArray, index) => {
//           // Iterate through each station in stnArray
//           stnArray.forEach((stationName) => {
//             const station = stations.find(station => station._.trim().replace(/\r?\n|\r/g, '') === stationName);
//             if (station) {
//               const name = station._.trim().replace(/\r?\n|\r/g, '');
//               const x = station.X;
//               const y = station.Y;
//               const z = station.Z;
//               console.log(`Name: ${name}`);
//               console.log(`X: ${x}`);
//               console.log(`Y: ${y}`);
//               console.log(`Z: ${z}`);
//               console.log('---------------');
//             }
//           });
//         });
//       });
//     });
//   });
// });



///////....,,,,,....///////////////////

// const fs = require('fs');
// const xml2js = require('xml2js');

// // Read the first XML file to get the 'JNUM' values
// fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', (err, journeyData) => {
//   if (err) throw err;

//   // Read the second XML file to get the 'SC' values
//   fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, stationData) => {
//     if (err) throw err;

//     // Parse the XML data for 'JOURNEY'
//     xml2js.parseString(journeyData, (err, journeyResult) => {
//       if (err) throw err;

//       // Parse the XML data for 'STATIONS'
//       xml2js.parseString(stationData, (err, stationResult) => {
//         if (err) throw err;
        
//         // Get the 'JNUM' values
//         const journeys = journeyResult.JOURNEY.JNUM;
        
//         // Get the 'STATIONS' values
//         const stations = stationResult.STATIONS.SC;

//         // Create an array to store the stn values for each journey
//         const stnArrays = [];

//         // Iterate through each 'JNUM' value
//         journeys.forEach((journey) => {
//           const journeyStations = journey.STN;
//           const stnValues = journeyStations.map(station => station.split(',')[0]);
//           stnArrays.push(stnValues);
//         });
//         console.log(stnArrays)
//         // Iterate through each 'SC' value
//         stations.forEach((station) => {
//           const name = station._.trim().replace(/\r?\n|\r/g, '');
//           const x = station.X[0];
//           const y = station.Y[0];
//           const z = station.Z[0];

//           // Check if the 'name' value exists in any of the stnArrays
//           stnArrays.forEach((stnArray) => {
//             if (stnArray.includes(name)) {
//               console.log(`Name: ${name}`);
//               console.log(`X: ${x}`);
//               console.log(`Y: ${y}`);
//               console.log(`Z: ${z}`);
//               console.log('---------------');
//             }
//           });
//         });
//       });
//     });
//   });
// });


//////............//////////////
// const fs = require('fs');
// const xml2js = require('xml2js');

// fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, data) => {
//   if (err) throw err;
  
//   xml2js.parseString(data, (err, result) => {
//     if (err) throw err;
    
//     const stations = result.STATIONS.SC;
//     const stationInfo = stations.map(station => {
//       const { _, X, Y, Z } = station;
//       const name = _.trim().replace(/\r?\n|\r/g, '');
//       return { name, X, Y, Z };
//     });
    
//     console.log(stationInfo);
//   });
// });



/////////////////////////////////////////////////
// const fs = require('fs');
// const xml2js = require('xml2js');

// fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, data) => {
//   if (err) throw err;
  
//   xml2js.parseString(data, (err, result) => {
//     if (err) throw err;
    
//     const stations = result.STATIONS.SC;
//     const stationInfo = stations.map(station => {
//       const x = station.X[0];
//       const y = station.Y[0];
//       const z = station.Z[0];
//       const name = station._.trim().replace(/\r?\n|\r/g, '');
//       return { name, x, y, z };
//     });
    
//     console.log(stationInfo);
//   });
// });



// const fs = require('fs');
// const xml2js = require('xml2js');
//     fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml', (err, data) => {
//       if (err) throw err;
//       // Parse the second XML data
//       xml2js.parseString(data, (err, result) => {
//         if (err) throw err;
//         const stations = result.STATIONS.SC;
//         console.log(stations)
//       })
//     });





/////////.//////////////////./////////
////////////////?///////////////////////
// const fs = require('fs');
// const xml2js = require('xml2js');

// // Read the XML file
// fs.readFile('C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml', (err, data) => {
//   if (err) throw err;

//   // Parse the XML data
//   xml2js.parseString(data, (err, result) => {
//     if (err) throw err;

//     // Get the 'STN' values
//     const journeys = result.JOURNEY.JNUM;
//      // Create an array to store the 'STN' values for each 'JOURNEY'
//     const stnArrays = [];
//     // console.log(journeys)
//     journeys.forEach((journey) => {
//       const stations = journey.STN;
//       // console.log(stations)
//       const stnValues = stations.map(station => station.split(',')[0]);
//       console.log(stnValues)
//       stnArrays.push(stnValues);
//     });
//     // console.log(stnArrays);
//   });
// });;



// /////////////////////////////////////
// const fs = require('fs');
// const { parseString } = require('xml2js');

// const filePath1 = 'C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml';
// const filePath2 = 'C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml';
// const desiredStation = 'your_desired_station';

// fs.readFile(filePath1, 'utf-8', (err, data1) => {
//   if (err) {
//     console.error('Error reading file:', err);
//     return;
//   }

//   parseString(data1, (err, result1) => {
//     if (err) {
//       console.error('Error parsing XML:', err);
//       return;
//     }

//     const journeys = result1.JOURNEY.JNUM;
//     let selectedJourney = null;

//     // Find the journey that contains the desired station
//     for (let i = 0; i < journeys.length; i++) {
//       const journey = journeys[i];
//       const stops = journey.STN;
//       console.log(stops)
//       if (stops.includes(desiredStation)) {
//         selectedJourney = journey;
//         break;
//       }
//     }

//     if (!selectedJourney) {
//       console.log('No journey found for the desired station.');
//       return;
//     }
//     console.log(selectedJourney)
//     const stationCodes = selectedJourney.STN;

//     fs.readFile(filePath2, 'utf-8', (err, data2) => {
//       if (err) {
//         console.error('Error reading file:', err);
//         return;
//       }

//       parseString(data2, (err, result2) => {
//         if (err) {
//           console.error('Error parsing XML:', err);
//           return;
//         }

//         const stations = result2.STATIONS.SC;
//         const stationData = [];

//         stationCodes.forEach(stationCode => {
//           const modifiedStationCode = stationCode.slice(0,-6); // Remove last 6 digits

//           const selectedStation = stations.find(station => 
//             station.SN_E[0] === modifiedStationCode ||
//             station.SN_H[0] === modifiedStationCode ||
//             station.SN_R[0] === modifiedStationCode
//           );

//           if (selectedStation) {
//             const xyzValues = {
//               stationCode: modifiedStationCode,
//               x: selectedStation.X[0],
//               y: selectedStation.Y[0],
//               z: selectedStation.Z[0]
//             };

//             stationData.push(xyzValues);
//           }
//         });

//         console.log(stationData);
//       });
//     });
//   });
// });

// process.on('uncaughtException', (err) => {
//   console.error('File system error:', err);
// });
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////


// const fs = require('fs');
// const { parseString } = require('xml2js');

// const filePath1 = 'C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml';
// const filePath2 = 'C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml';
// const desiredStation = 'GWL';

// fs.readFile(filePath1, 'utf-8', (err, data1) => {
//   if (err) {
//     console.error('Error reading file:', err);
//     return;
//   }

//   parseString(data1, (err, result1) => {
//     if (err) {
//       console.error('Error parsing XML:', err);
//       return;
//     }

//     const journeys = result1.JOURNEY.JNUM;
//     let selectedJourney = null;

//     // Find the journey that contains the desired station
//     for (let i = 0; i < journeys.length; i++) {
//       const journey = journeys[i];
//         const stops = journey.STN;
//         console.log(stops)
      
//     }
//     if (!selectedJourney) {
//       console.log('No journey found for the desired station.');
//       return;
//     }

//     const stationCodes = selectedJourney.STN;

//     fs.readFile(filePath2, 'utf-8', (err, data2) => {
//       if (err) {
//         console.error('Error reading file:', err);
//         return;
//       }

//       parseString(data2, (err, result2) => {
//         if (err) {
//           console.error('Error parsing XML:', err);
//           return;
//         }

//         const stations = result2.STATIONS.SC;
//         const stationData = [];

//         stationCodes.forEach(stationCode => {
//           const selectedStation = stations.find(station => station.SN_E[0] === stationCode || station.SN_H[0] === stationCode || station.SN_R[0] === stationCode);

//           if (selectedStation) {
//             const xyzValues = {
//               stationCode,
//               x: selectedStation.X[0],
//               y: selectedStation.Y[0],
//               z: selectedStation.Z[0]
//             };

//             stationData.push(xyzValues);
//           }
//         });

//         console.log(stationData);
//       });
//     });
//   });
// });

// process.on('uncaughtException', (err) => {
//   console.error('File system error:', err);
// });





/////////////////////////////////////////////////
// const fs = require('fs');
// const { parseString } = require('xml2js');

// const filePath1 = 'C:\\Users\\PTCS\\Desktop\\test2\\journey_database.xml';
// const filePath2 = 'C:\\Users\\PTCS\\Desktop\\test2\\station_database.xml';

// fs.readFile(filePath1, 'utf-8', (err, data1) => {
//   if (err) {
//     console.error('Error reading file:', err);
//     return;
//   }

//   parseString(data1, (err, result1) => {
//     if (err) {
//       console.error('Error parsing XML:', err);
//       return;
//     }

//     const desiredStation = 'NZM'; // Replace with the desired station code
//     const journeys = result1.JOURNEY.JNUM;
//       let selectedJourney = null;
//     //   console.log(journeys)
//     // Find the journey that contains the desired station
//     for (let i = 0; i < journeys.length; i++) {
//       const journey = journeys[i];
//         const stops = journey.STN;
//         console.log(stops)
//       if (stops.includes(desiredStation)) {
//           selectedJourney = journey;
//           console.log(selectedJourney)
//         break;
//       }
//     }

//     if (!selectedJourney) {
//       console.log('No journey found for the desired station.');
//       return;
//     }

//     const stationCode = selectedJourney.STN.find(station => station.includes(desiredStation));
    
//     fs.readFile(filePath2, 'utf-8', (err, data2) => {
//       if (err) {
//         console.error('Error reading file:', err);
//         return;
//       }

//       parseString(data2, (err, result2) => {
//         if (err) {
//           console.error('Error parsing XML:', err);
//           return;
//         }

//         const stations = result2.STATIONS.SC;
//         const selectedStation = stations.find(station => station.SN_E[0] === stationCode || station.SN_H[0] === stationCode || station.SN_R[0] === stationCode);

//         if (!selectedStation) {
//           console.log('No station found for the desired station code.');
//           return;
//         }

//         const xyzValues = {
//           x: selectedStation.X[0],
//           y: selectedStation.Y[0],
//           z: selectedStation.Z[0]
//         };

//         console.log(xyzValues);
//       });
//     });
//   });
// });
