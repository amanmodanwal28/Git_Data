const fs = require('fs');
const xml2js = require('xml2js');
const express = require('express');
const multer = require('multer');
const app = express();
const port = 3000;


app.use(express.static('public/')); // Serve static files in the 'public' directory
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});
const upload = multer({ storage: storage });
app.post('/process', upload.single('file'), (req, res) => {
  const filePath = req.file.path;
        fs.readFile(filePath, (err, journeyData) => {
            if (err) {
                console.error(err);
                return res.status(500).send(err);
            }

            xml2js.parseString(journeyData, (err, journeyResult) => {
                if (err) {
                    console.error(err);
                    return res.status(500).send(err);
                }

                const journeys = journeyResult.JOURNEY.JNUM;
                const stnArrays = [];

                journeys.forEach((journey) => {
                    const Station_name = journey.TNAME_E;
                    console.log(Station_name);

                    const journeyStations = journey.STN;
                    const stnValues = journeyStations.map(station => station.split(',')[0]);
                    stnArrays.push(stnValues);

                    console.log(stnValues);
                });
 
                res.send(stnArrays);
            });
        });
    });


app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
  console.log(`Server is running on http://localhost:${port}`);
});
