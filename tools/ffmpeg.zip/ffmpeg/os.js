const { exec } = require('child_process')
const path = require('path') // Require the path module
const fs = require('fs')

// New path to add
const newPath = __dirname

// PowerShell command to set environment variable
const command = `powershell -Command "[Environment]::SetEnvironmentVariable('PATH', '${process.env.PATH}${path.delimiter}${newPath}', 'User')"`

exec(command, (err, stdout, stderr) => {
    if (err) {
        console.error(`Error: ${err.message}`)
        return
    }
    console.log('Path added successfully!')
})




// const { exec } = require('child_process')
// const path = require('path') // Require the path module

// // New path to add
// const newPath = 'C:\\lux cozi'

// // PowerShell command to set environment variable
// const command = `powershell -Command "[Environment]::SetEnvironmentVariable('PATH', '${process.env.PATH}${path.delimiter}${newPath}', 'User')"`

// exec(command, (err, stdout, stderr) => {
//     if (err) {
//         console.error(`Error: ${err.message}`)
//         return
//     }
//     console.log('Path added successfully!')
// })

// const env = process.env.PATH
// console.log(env);
// const envPAth = env.split(';')

// const newpath = 'C:\\aman111'

// const newEnvPATH = envPAth.push(newpath)

// console.log(envPAth)