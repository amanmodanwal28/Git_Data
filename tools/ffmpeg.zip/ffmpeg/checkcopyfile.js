const path = require('path')
const fs = require('fs').promises

async function copyFile() {
    try {
        await fs.copyFile('./content/Add2/MA0015MR.MP3', './MA0015MR.MP3')
        console.log('File copied successfully')
    } catch (error) {
        console.error('Error copying file:', error)
    }
}

copyFile()