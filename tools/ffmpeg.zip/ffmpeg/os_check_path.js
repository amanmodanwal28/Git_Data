const fs = require('fs')
const path = require('path')

// Array of fixed drive letters to check on Windows
const driveLetters = [
    'A:',
    'B:',
    'C:',
    'D:',
    'E:',
    'F:',
    'G:',
    'H:',
    'I:',
    'J:',
    'K:',
    'L:',
    'M:',
    'N:',
    'O:',
    'P:',
    'Q:',
    'R:',
    'S:',
    'T:',
    'U:',
    'V:',
    'W:',
    'X:',
    'Y:',
    'Z:'
]

// Function to check if a directory exists synchronously
function directoryExistsSync(dirPath) {
    try {
        return fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory()
    } catch (err) {
        return false
    }
}

// Function to find if 'ffmpeg\\bin' directory exists in any fixed drive
function findFFMPEGBinDirectory() {
    for (let drive of driveLetters) {
        const fullPath = path.join(drive, 'ffmpeg', 'bin')
        if (directoryExistsSync(fullPath)) {
            return fullPath
        }
    }
    return null
}

// Check if 'ffmpeg\\bin' directory exists
const ffmpegBinPath = findFFMPEGBinDirectory()
if (ffmpegBinPath) {
    console.log(`'ffmpeg\\bin' directory found at: ${ffmpegBinPath}`)
} else {
    console.log(`'ffmpeg\\bin' directory not found.`)
}