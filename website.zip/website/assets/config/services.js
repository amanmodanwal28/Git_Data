services = [
 
  {
    name: "Meals",
    imgPath: "dish.png",
  },
  {
    name: "Cleanliness",
    imgPath: "clean.png",
  },

  {
    name: "Fire",
    imgPath: "fire.png",
  },

  {
    name: "Emergency Stop",
    imgPath: "stop.png",
  },
  {
    name: "Medical",
    imgPath: "doctor.png",
  },
  {
    name: "Security",
    imgPath: "security.png",
  }
];
