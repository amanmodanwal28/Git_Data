pisconfig =

{
  
 
  
    DisplayEnglish: [{ Name: "Last Updated On", Index1: 0, Index2:1 },
    { Name: "Speed", Index1: 2 },{ Name: "Next Stop", Index1: 5 }
    ],

    TripStartDate: 5,
    TripStartTime: 6,
    PAS: 7,
     startIndex : 2,
     totalLanguages : 5,
     totalStations : 5,
    presentStation :{ id:2, name:"Present Station" },
    nextStation :{id:4, name:"Next Station"} ,
    time:5,
    pas :"Please Listen to Announcement...!",
    df:"102",
    j:"No Data Available"



}
