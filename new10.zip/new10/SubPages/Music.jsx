import React, { useEffect, useState, useRef } from 'react';
import MarqueeWithBack from "../Component/MarqueeWithBack";
import Banner from "../Component/Banner";
import Footer from "../Component/Footer";
import useFetchDataWithIp from '../Api/useFetchDataWithIp';
import '../Css/Music.css';
import Popup from '../Component/Popup';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBackward, faForward, faPause, faPlay, faVolumeUp } from '@fortawesome/free-solid-svg-icons';

const Music = () => {
  const [fileList, setFileList] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [currentSong, setCurrentSong] = useState(null);
  const [currentSongIndex, setCurrentSongIndex] = useState(0);
  const audioRef = useRef(null);
  const { serverIp } = useFetchDataWithIp();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0); // Current time of the audio
  const [duration, setDuration] = useState(0); // Duration of the audio

  useEffect(() => {
    if (serverIp) {
      fetch(`${serverIp}/music`)
        .then((response) => {
          if (!response.ok) throw new Error('Network response was not ok');
          return response.json();
        })
        .then(data => setFileList(data))
        .catch(error => console.error('Error fetching files:', error));
    }
  }, [serverIp]);

  useEffect(() => {
    if (fileList.length > 0 && !selectedCategory) {
      const firstCategory = fileList.find(file => file.type === 'directory');
      if (firstCategory) setSelectedCategory(firstCategory.name);
    }
  }, [fileList, selectedCategory]);

  const categories = fileList.filter(file => file.type === 'directory').slice(0, 4);

  const capitalizeFirstLetter = (string) => {
    if (!string) return '';
    return string.charAt(0).toUpperCase() + string.slice(1);
  };

  const renderCategory = (category) => (
    <div
      key={category.name}
      className={`category-box ${selectedCategory === category.name ? 'selected' : ''}`}
      onClick={() => setSelectedCategory(category.name)}
    >
      <strong>{capitalizeFirstLetter(category.name)}</strong>
    </div>
  );

  const renderSongs = (category) => {
    const songs = fileList.find(file => file.name === category)?.children || [];
    return songs.map((song, index) => {
      const isPlaying = currentSong === song.name;
      return (
        <li
          key={song.name || `${category}-${index}`}
          className={isPlaying ? 'highlight' : ''}
          onClick={() => handleSongClick(song.name, index)}
        >
          <span>
            {index + 1}. {capitalizeFirstLetter(song.name)}
          </span>
        </li>
      );
    });
  };

  const handleSongClick = (songName, index) => {
    if (currentSong === songName) return;

    setCurrentSong(songName);
    setCurrentSongIndex(index);

    if (audioRef.current) {
      audioRef.current.pause(); // Pause current song if playing
      audioRef.current.src = `${serverIp}/music/${selectedCategory}/${songName}`;
      audioRef.current.load();
      audioRef.current.play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch(error => console.error('Error playing audio:', error));
    }
  };

  const handleNextSong = () => {
    const songs = fileList.find(file => file.name === selectedCategory)?.children || [];
    const nextIndex = (currentSongIndex + 1) % songs.length;
    handleSongClick(songs[nextIndex].name, nextIndex);
  };

  const handlePreviousSong = () => {
    const songs = fileList.find(file => file.name === selectedCategory)?.children || [];
    const prevIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    handleSongClick(songs[prevIndex].name, prevIndex);
  };

  useEffect(() => {
    const currentAudio = audioRef.current;

    const handleTimeUpdate = () => {
      setCurrentTime(currentAudio.currentTime);
      setDuration(currentAudio.duration);
    };

    if (currentAudio) {
      currentAudio.addEventListener('timeupdate', handleTimeUpdate);
      currentAudio.addEventListener('ended', handleNextSong);
      return () => {
        currentAudio.removeEventListener('timeupdate', handleTimeUpdate);
        currentAudio.removeEventListener('ended', handleNextSong);
      };
    }
  }, [currentSong]);

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  const togglePlayPause = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <>
      <Popup />
      <MarqueeWithBack />
      <Banner />
      <div className="music-container" style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
        <div style={{ flex: '1', padding: '10px', overflow: 'hidden' }}>
          <h2>Music Categories:</h2>
          <div className="category-container">
            {categories.map(renderCategory)}
          </div>
          {selectedCategory && (
            <>
              <h2>Songs in {capitalizeFirstLetter(selectedCategory)}:</h2>
              <ul className="file-list" style={{
                padding: '0',
                listStyle: 'none',
                margin: '0',
                height: 'calc(100% - 180px)',
                overflowY: 'scroll',
              }} onContextMenu={(e) => e.preventDefault()}>
                {renderSongs(selectedCategory)}
              </ul>
            </>
          )}
        </div>
        <div className="audio-controls" style={{
          backgroundColor: 'teal',
          padding: '8px',
          textAlign: 'center',
          borderTop: '1px solid #ddd',
          marginTop: '10px',
        }}>
          <span style={{ display: 'block', marginBottom: '1px', color: 'white' }}>
            {currentSong ? `Now Playing: ${currentSong}` : 'Select a song to play'}
          </span>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '8px' }}>
            <span style={{ color: 'white', marginRight: '8px' }}>
              {formatTime(currentTime)}
            </span>
            <input
              type="range"
              min="0"
              max={duration || 1}
              value={currentTime}
              onChange={(e) => {
                const newTime = e.target.value;
                audioRef.current.currentTime = newTime;
                setCurrentTime(newTime);
              }}
              style={{ width: '90%', margin: '0 8px' }}
            />
            <span style={{ color: 'white', marginLeft: '8px' }}>
              {duration ? formatTime(duration) : '0:00'}
            </span>
          </div>
          <div style={{ marginTop: '8px' }}>
            <button onClick={handlePreviousSong} style={{ margin: '0 10px', background: 'transparent', border: 'none', cursor: 'pointer' }}>
              <FontAwesomeIcon icon={faBackward} style={{ color: 'white', fontSize: '24px' }} />
            </button>
            <button onClick={togglePlayPause} style={{ margin: '0 10px', background: 'transparent', border: 'none', cursor: 'pointer' }}>
              <FontAwesomeIcon icon={isPlaying ? faPause : faPlay} style={{ color: 'white', fontSize: '24px' }} />
            </button>
            <button onClick={handleNextSong} style={{ margin: '0 10px', background: 'transparent', border: 'none', cursor: 'pointer' }}>
              <FontAwesomeIcon icon={faForward} style={{ color: 'white', fontSize: '26px' }} />
            </button>
            
          </div>
          <audio ref={audioRef} preload="none" />
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Music;
