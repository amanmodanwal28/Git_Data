import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import WatchPage from './WatchPage'; // Create a component for watching videos

function App() {
  return (
    <Router>
      <Routes>
        {/* Other routes */}
        <Route path="/watch/:category/:videoName" element={<WatchPage />} />
      </Routes>
    </Router>
  );
}

export default App;
