/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MarqueeWithBack from '../Component/MarqueeWithBack';
import Banner from '../Component/Banner';
import Footer from '../Component/Footer';
import '../Css/Tourist.css';
import useFetchDataWithIp from '../Api/useFetchDataWithIp';
import defaultImage from '../content/default_img/folder_img.png';

const Tourist = () => {
  const [places, setPlaces] = useState([]);
  const [imageUrls, setImageUrls] = useState([]); // State to hold image URLs
  const navigate = useNavigate();
  const { serverIp } = useFetchDataWithIp();
  const baseUrl = `${serverIp}/tourist/`;

  // Function to fetch places and check image existence
  const fetchPlacesAndImages = () => {
    if (serverIp) {
      fetch(`${serverIp}/database/tourist.json`) // Fetching from the API
        .then((response) => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then((data) => {
          setPlaces(data); // Set the fetched data to state

          // Check image existence for each place
          const urls = data.map((place) => {
            const imageUrl = `${baseUrl}${place.image}`;
            return fetch(imageUrl)
              .then((response) => (response.ok ? imageUrl : defaultImage))
              .catch(() => defaultImage); // Fallback on error
          });

          Promise.all(urls).then((resolvedUrls) => setImageUrls(resolvedUrls));
        })
        .catch((error) => console.error('Error fetching data:', error));
    }
  };

  // Effect to poll for changes every 5 seconds
  useEffect(() => {
    fetchPlacesAndImages(); // Initial fetch

    const intervalId = setInterval(fetchPlacesAndImages, 1000); // Poll every 5 seconds

    return () => clearInterval(intervalId); // Cleanup interval on unmount
  }, [serverIp]);

  const handleImageClick = (place) => {
    navigate(`/place/${place.name.toLowerCase().replace(/\s+/g, '-')}`, {
      state: place,
    });
  };

  return (
    <>
      <MarqueeWithBack />
      <Banner />
      <h1 className="tourist-heading" onContextMenu={(e) => e.preventDefault()}>
        Tourist Places
      </h1>

      <div className="tourist-container" onContextMenu={(e) => e.preventDefault()}>
        {places.map((place, index) => (
          <div key={place.name} className={`place-item ${index % 2 === 0 ? 'left' : 'right'}`}>
            <div className="DataTouristAllInfo">
              <h2 className="place-title" onClick={() => handleImageClick(place)}>
                {place.name}
              </h2>
              <div className="DataTouristInfo">
                {index % 2 === 0 ? (
                  <>
                    <img
                      alt={`Image of ${place.name}`}
                      src={imageUrls[index]} // Use the resolved image URL or default
                      className="place-image"
                      onClick={() => handleImageClick(place)}
                      onContextMenu={(e) => e.preventDefault()}
                    />
                    <div className="place-content">
                      <p className="place-description" onClick={() => handleImageClick(place)}>
                        {place.description}
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="place-content">
                      <p className="place-description" onClick={() => handleImageClick(place)}>
                        {place.description}
                      </p>
                    </div>
                    <img
                      alt={`Image of ${place.name}`}
                      src={imageUrls[index]} // Use the resolved image URL or default
                      className="place-image"
                      onClick={() => handleImageClick(place)}
                      onContextMenu={(e) => e.preventDefault()}
                    />
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <Footer />
    </>
  );
};

export default Tourist;
