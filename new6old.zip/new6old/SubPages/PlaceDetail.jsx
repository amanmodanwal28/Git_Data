/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import MarqueeWithBack from '../Component/MarqueeWithBack';
import Banner from '../Component/Banner';
import Footer from '../Component/Footer';
import '../Css/PlaceDetail.css';
import useFetchDataWithIp from '../Api/useFetchDataWithIp';
import DefaultImage  from '../content/default_img/folder_img.png'



const PlaceDetail = () => {
  const location = useLocation();
  const place = location.state; // Access the place data passed through state
  const [imageUrl, setImageUrl] = useState(DefaultImage); // Initialize with default image
  const { serverIp } = useFetchDataWithIp();
  const baseUrl = `${serverIp}/tourist/`; // Use the correct base URL for images
  if (!place) {
    return <h2>No place data available.</h2>;
  }

  // Dynamically determine the image URL
  useEffect(() => {
    const imgSrc = `${baseUrl}${place.image}`;
    fetch(imgSrc)
      .then((response) => {
        if (response.ok) {
          setImageUrl(imgSrc); // Set imageUrl if the image exists
        } else {
          setImageUrl(DefaultImage); // Set to default if the image doesn't exist
        }
      })
      .catch(() => {
        setImageUrl(DefaultImage); // Set to default on error
      });
  }, [place.image,baseUrl]);


  return (
    <>
      <MarqueeWithBack />
      <Banner />
      <div className="place-detail">
        <h1>{place.name}</h1>
        <img
          src={imageUrl} // Use the constructed image URL
          alt={place.name}
          className="place-detail-image"
          onContextMenu={(e) => e.preventDefault()}
        />
        
        <p
          className="place-description"
          dangerouslySetInnerHTML={{ __html: place.descriptionDetail }}
        />
      </div>
      <Footer />
    </>
  );
};

export default PlaceDetail;
