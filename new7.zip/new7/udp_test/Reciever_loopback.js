const dgram = require('dgram')

const PORT = 8001
const HOST = '127.0.0.1' // Loopback IP for receiver

const udpSocket = dgram.createSocket('udp4')

udpSocket.on('error', (error) => {
  console.log(`Socket error: ${error.stack}`)
  udpSocket.close()
})

udpSocket.on('message', (message, remoteInfo) => {
  console.log(`Message Receive from loopBack Ip: ${message}`)
})

udpSocket.bind(PORT, HOST, () => {
  console.log(`Listening for messages on ${HOST}:${PORT}`)
})
