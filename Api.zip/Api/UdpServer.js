import dgram from 'dgram' // For UDP// To create an HTTP server for socket.io
import { Server } from 'socket.io' // WebSocket

const UDP_PORT = 8001 // UDP server port
const LOOPBACK_HOST = '0.0.0.0' // Loopback IP for UDP

// Create the UDP server
const udpServer = dgram.createSocket('udp4')
// Function to create and start the UDP server and WebSocket
export const startUDPServer = (server) => {
  // Initialize the socket.io server
  const io = new Server(server, {
    cors: {
      origin: '*', // Allow all origins (you can restrict this to your front-end URL)
      methods: ['GET', 'POST'],
    },
  })

  // Handle WebSocket connections
  io.on('connection', (socket) => {
    console.log('WebSocket client connected')
    socket.on('disconnect', () => {
      console.log('WebSocket client disconnected')
    })
  })

  // When the UDP server receives a message
  udpServer.on('message', (msg, rinfo) => {
    console.log(`Received message: ${msg} from ${rinfo.address}:${rinfo.port}`)
    // Send the received message to all connected WebSocket clients
    io.emit('udpMessage', msg.toString()) // Emit the UDP message to WebSocket clients
  })

  // Bind the UDP server to the PORT and LOOPBACK_HOST
  udpServer.bind(UDP_PORT, LOOPBACK_HOST)

  // Handle graceful shutdown
  process.on('SIGINT', () => {
    udpServer.close(() => {
      console.log('UDP server closed')
      process.exit()
    })
  })
}
