import helmet from 'helmet'
import jwt from 'jsonwebtoken'
import { body, validationResult } from 'express-validator'

import rateLimit from 'express-rate-limit'
import CryptoJS from 'crypto-js' // Import crypto-js

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key' // Set your secret key
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'your_encryption_key' // Set your encryption key
import cors from 'cors'




// Middleware to authenticate token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization']
  const encryptedToken = authHeader && authHeader.split(' ')[1]

  if (!encryptedToken) {
    return res.status(401).json({ message: 'Unauthorized' })
  }

  try {
    // Decrypt the token
    const bytes = CryptoJS.AES.decrypt(encryptedToken, ENCRYPTION_KEY)
    const decryptedToken = bytes.toString(CryptoJS.enc.Utf8)

    if (!decryptedToken) {
      return res.status(403).json({ message: 'Forbidden: Invalid token' })
    }

    // Verify the JWT
    jwt.verify(decryptedToken, JWT_SECRET, (err, user) => {
      if (err) {
        return res.status(403).json({ message: 'Forbidden' })
      }
      req.user = user
      next()
    })
  } catch (error) {
    console.error('Error during token decryption:', error)
    return res.status(403).json({ message: 'Forbidden: Invalid token' })
  }
}

export const authentication = (app) => {
  app.use(helmet())

  // Rate limiting middleware
  const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 100, // Limit each IP to 100 requests per windowMs
  })

  app.use(limiter)

  // Route for generating a token (no username input required)
  app.post(
    '/login',
    [
      // Validate input
      body('username').exists().isString(),
      body('password').exists().isLength({ min: 5 }),
    ],
    (req, res) => {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      // Create user object
      const user = { name: 'aman modanwal' } // Example user, based on input
      const accessToken = jwt.sign(user, JWT_SECRET, { expiresIn: '15m' })
      // Encrypt the token before sending it to the client
      const encryptedToken = CryptoJS.AES.encrypt(
        accessToken,
        ENCRYPTION_KEY
      ).toString()
      res.json({ accessToken: encryptedToken })
    }
  )

  // Centralized error handling middleware
  app.use((err, req, res, next) => {
    console.error(err.stack)
    res.status(500).json({ message: 'Internal Server Error' })
  })

  console.log('hello from authentication')
  return { authenticateToken }
}
