/* eslint-disable no-unused-vars */
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import MarqueeWithBack from '../Component/MarqueeWithBack'
import Banner from '../Component/Banner' // Ensure this path is correct
import Footer from '../Component/Footer'
import '../Css/Tourist.css'

const images = ['kashmir.png', 'tajmahal.png', 'chittor.png']

const Tourist = () => {
  const [currentIndex, setCurrentIndex] = useState(0)
  const navigate = useNavigate()

  const handleNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    )
  }

  const handlePrev = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    )
  }

  return (
    <>
      <MarqueeWithBack />
      <Banner /> {/* Ensure the Banner component renders here */}
      <h1 className="tourist-heading" onContextMenu={(e) => e.preventDefault()}>
        Tourist Places
      </h1>
      <div className="slider-container">
        <button className="arrow left-arrow" onClick={handlePrev}>
          &lt;
        </button>
        <img
          alt={`Image ${currentIndex + 1}`}
          src={`src/content/img/tourist/${images[currentIndex]}`}
          className="slider-image"
        />
        <button className="arrow right-arrow" onClick={handleNext}>
          &gt;
        </button>
      </div>
      <Footer />
    </>
  )
}

export default Tourist
