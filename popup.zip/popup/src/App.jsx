import './App.css' // Ensure you import your CSS file here
import Popup from './Popup'
import { useRef } from 'react'
import videosrc from './assets/motu.mp4'
import musicsrc from './assets/dheemi.mp3'

function App() {
  const videoRef = useRef(null)
  const audioRef = useRef(null)

  const pauseMedia = () => {
    if (videoRef.current) {
      videoRef.current.pause() // Pause the video
    }
    if (audioRef.current) {
      audioRef.current.pause() // Pause the audio
    }
  }

  const resumeMedia = () => {
    if (videoRef.current) {
      videoRef.current.play() // Resume the video
    }
    if (audioRef.current) {
      audioRef.current.play() // Resume the audio
    }
  }

  return (
    <div className="App">
      {/* Popup to show while data is being sent */}
      <Popup pauseMedia={pauseMedia} resumeMedia={resumeMedia} />

      {/* Background content (can be any content you want) */}
      <div className="content">
        <h1>Background Content</h1>

        {/* Video Section */}
        <div className="video-section">
          <h2>Video Section</h2>
          <video ref={videoRef} controls width="600">
            <source src={videosrc} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>

        {/* Audio Section */}
        <div className="audio-section">
          <h2>Audio Section</h2>
          <audio ref={audioRef} controls>
            <source src={musicsrc} type="audio/mp3" />
            Your browser does not support the audio tag.
          </audio>
        </div>
      </div>
    </div>
  )
}

export default App
