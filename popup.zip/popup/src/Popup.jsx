/* eslint-disable react/prop-types */
import { useEffect, useState } from 'react'
import './Popup.css' // Importing CSS for the popup

const Popup = ({ pauseMedia, resumeMedia }) => {
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    // Function to show the popup and manage media playback
    const togglePopup = () => {
      setIsOpen((prevState) => {
        const newState = !prevState // Toggle the state
        if (newState) {
          pauseMedia() // Pause any media when the popup opens
        } else {
          resumeMedia() // Resume any media when the popup closes
        }
        return newState // Return the new state
      })
    }

    // Show the popup after 30 seconds
    const initialTimer = setTimeout(() => {
      togglePopup() // Show the popup after 30 seconds
      // Set an interval to continue toggling the popup every 12 seconds
      const intervalId = setInterval(togglePopup, 7000)

      // Clear the interval when the component unmounts
      return () => clearInterval(intervalId)
    }, 15000) // 30 seconds

    // Cleanup the initial timer on unmount
    return () => clearTimeout(initialTimer)
  }, [pauseMedia, resumeMedia]) // Dependencies include pauseMedia and resumeMedia

  if (!isOpen) return null // If popup is not open, render nothing

  return (
    <div className="popup-overlay">
      <div className="popup-box">
        <h2>PA in Progress.....</h2>
      </div>
    </div>
  )
}

export default Popup
