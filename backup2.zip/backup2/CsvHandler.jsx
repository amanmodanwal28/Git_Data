/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';

const CsvHandler = () => {
    const [data, setData] = useState([]);
    const [pnr, setPnr] = useState('');
    const [passengerName, setPassengerName] = useState('');
    const [contactNumber, setContactNumber] = useState('');
    const [seatNumber, setSeatNumber] = useState('');
    const [serviceType, setServiceType] = useState('');
    const [complaint, setComplaint] = useState('');

    useEffect(() => {
        // Fetch data from the API
        fetch('http://localhost:5000/data')
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then((jsonData) => {
                setData(jsonData);
            })
            .catch((error) => console.error('Error fetching the data:', error));
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();

        const newEntry = {
            pnr,
            passengerName,
            contactNumber,
            seatNumber,
            serviceType,
            complaint,
            date: new Date().toLocaleDateString(), // Add current date
            time: new Date().toLocaleTimeString(),   // Add current time
            status: 'open' ,
            actionTaken: 'No_Action_Taken'                 // Add status
        };

        // Post new data to the API
        fetch('http://localhost:5000/data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newEntry),
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then((result) => {
                console.log('Data saved successfully:', result);
                // Update local state
                setData((prevData) => [...prevData, newEntry]);
                // Reset form fields
                setPnr('');
                setPassengerName('');
                setContactNumber('');
                setSeatNumber('');
                setServiceType('');
                setComplaint('');
            })
            .catch((error) => {
                console.error('Error saving data to the API:', error);
            });
    };

    return (
        <div>
            <h1>CSV Data</h1>
            <form method="POST" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="pnr">PNR Number:</label>
                    <input
                        type="text"
                        id="pnr"
                        name="pnr"
                        value={pnr}
                        onChange={(e) => setPnr(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="passengerName">Passenger Name:</label>
                    <input
                        type="text"
                        id="passengerName"
                        name="passengerName"
                        value={passengerName}
                        onChange={(e) => setPassengerName(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="contactNumber">Contact Number:</label>
                    <input
                        type="tel"
                        id="contactNumber"
                        name="contactNumber"
                        value={contactNumber}
                        onChange={(e) => setContactNumber(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="seatNumber">Seat Number:</label>
                    <input
                        type="text"
                        id="seatNumber"
                        name="seatNumber"
                        value={seatNumber}
                        onChange={(e) => setSeatNumber(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="serviceType">Services:</label>
                    <select
                        id="serviceType"
                        name="serviceType"
                        value={serviceType}
                        onChange={(e) => setServiceType(e.target.value)}
                        required
                    >
                        <option value="">Select Service</option>
                        <option value="Emergency">Emergency</option>
                        <option value="Security">Security</option>
                        <option value="Linen">Linen</option>
                        <option value="Veg">Veg</option>
                        <option value="Non Veg">Non Veg</option>
                        <option value="Special Case">Special Case</option>
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="complaint">Write Your Complaint Here:</label>
                    <textarea
                        id="complaint"
                        name="complaint"
                        value={complaint}
                        onChange={(e) => setComplaint(e.target.value)}
                        required
                    ></textarea>
                </div>
                <div className="button-group">
                    <button type="submit">Submit</button>
                    <button type="button">Existing</button>
                </div> 
            </form>

            <h2>Current Data:</h2>
            <ul>
                {data.map((item, index) => (
                    <li key={index}>
                        {item.pnr} - {item.passengerName} - {item.contactNumber}  - {item.seatNumber} - {item.serviceType} - 
                        {item.date} {item.time} - {item.status} - {item.actionTaken}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default CsvHandler;
