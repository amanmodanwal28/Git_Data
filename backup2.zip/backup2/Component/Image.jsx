/* eslint-disable no-unused-vars */
import React from "react";
import "../Css/Banner.css"; // Adjust the import if needed

const images = import.meta.glob('../content/add/*.{png,jpg,jpeg,svg}');

const ImageList = () => {
    return (
        <div className="image-list">
            {Object.entries(images).map(([key, value]) => (
                <img
                    key={key}
                    src={value()} // Call the function to get the image URL
                    alt={key}
                    style={{ width: '100px', margin: '10px' }}
                />
            ))}
        </div>
    );
};

export default ImageList;
