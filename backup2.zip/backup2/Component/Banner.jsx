/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import '../Css/Banner.css'; // Adjust the path if neede

const images = import.meta.glob('../content/add/*.{png,jpg,jpeg,svg}');
const videos = import.meta.glob('../content/add/*.{mp4,webm}');

const media = [...Object.entries(images), ...Object.entries(videos)];

const Banner = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [mediaUrl, setMediaUrl] = useState('');
 
  useEffect(() => {
    const loadMedia = async () => {
      const [mediaKey, mediaValue] = media[currentIndex] || [];
      if (mediaValue) {
        try {
          const resolvedModule = await mediaValue();
          const url = resolvedModule.default || resolvedModule; // Get the URL string
          setMediaUrl(url);
        } catch (error) {
          console.error("Error loading media:", error);
        }
      }
    };

    loadMedia();

    const intervalId = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % media.length);
    }, 5000); // Change every 5 seconds

    return () => clearInterval(intervalId);
  }, [currentIndex]);

  const [mediaKey] = media[currentIndex] || [];

  return (
    <>
      <div className="banner">
       
        <div className="media-container">
          {mediaUrl && (
            mediaKey.endsWith('.mp4') || mediaKey.endsWith('.webm') ? (
              <video key={mediaKey} src={mediaUrl} autoPlay loop muted />
            ) : (
              <img key={mediaKey} src={mediaUrl} alt={mediaKey} />
            )
          )}
        </div>
      </div>
      
    </>
  );
};

export default Banner;
