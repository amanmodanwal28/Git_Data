/* eslint-disable no-unused-vars */
import React, { useEffect, useState, useRef } from 'react';
import MarqueeWithBack from "../Component/MarqueeWithBack";
import Banner from "../Component/Banner";
import Footer from "../Component/Footer";
import WaveSurfer from 'wavesurfer.js';
import '../Css/Music.css';

const Music = () => {
  const [fileList, setFileList] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [currentSong, setCurrentSong] = useState(null);
  const audioRef = useRef(null);
  const waveformRef = useRef(null);
  const waveSurferRef = useRef(null);

  useEffect(() => {
    fetch('http://192.168.10.15:5000/api/music')
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
      })
      .then(data => setFileList(data))
      .catch(error => console.error('Error fetching files:', error));
  }, []);

  // Initialize WaveSurfer when the component mounts and the ref is available
  useEffect(() => {
    if (waveformRef.current) {
      waveSurferRef.current = WaveSurfer.create({
        container: waveformRef.current,
        waveColor: 'violet',
        progressColor: 'purple',
        height: 80,
      });

      waveSurferRef.current.on('finish', handleNextSong);

      return () => {
        waveSurferRef.current.destroy();
      };
    }
  }, [waveformRef.current]);

  const categories = fileList.filter(file => file.type === 'directory').slice(0, 4);

  const renderCategory = (category) => (
    <div key={category.name} className="category-box" onClick={() => setSelectedCategory(category.name)}>
      <strong>{category.name}</strong>
    </div>
  );

  const renderSongs = (category) => {
    const songs = fileList.find(file => file.name === category)?.children || [];
    return songs.map((song, index) => (
      <li key={song.name || `${category}-${index}`} 
          className={currentSong === song.name ? 'highlight' : ''} 
          onClick={() => handleSongClick(song.name)}>
        {index + 1}. {song.name}
      </li>
    ));
  };

  const handleSongClick = (songName) => {
    if (currentSong === songName) {
      setCurrentSong(null);
      if (waveSurferRef.current) {
        waveSurferRef.current.stop();
      }
    } else {
      setCurrentSong(songName);
      if (waveSurferRef.current) {
        waveSurferRef.current.load(`src/content/music/${selectedCategory}/${songName}`);
        waveSurferRef.current.play();
      }
    }
  };

  const handleNextSong = () => {
    const songs = fileList.find(file => file.name === selectedCategory)?.children || [];
    const currentIndex = songs.findIndex(song => song.name === currentSong);
    const nextIndex = (currentIndex + 1) % songs.length; // Loop back to first song
    const nextSong = songs[nextIndex].name;

    setCurrentSong(nextSong);
    if (waveSurferRef.current) {
      waveSurferRef.current.load(`src/content/music/${selectedCategory}/${nextSong}`);
      waveSurferRef.current.play(); // Automatically play the next song
    }
  };

  return (
    <>
      <MarqueeWithBack />
      <Banner />
      <div className="music-container">
        <h2>Music Categories:</h2>
        <div className="category-container">
          {categories.map(renderCategory)}
        </div>

        {selectedCategory && (
          <>
            <h2>Songs in {selectedCategory}:</h2>
            <ul className="file-list">
              {renderSongs(selectedCategory)}
            </ul>
            {currentSong && (
              <div className="current-song">
                <strong>Now Playing:</strong> {currentSong}
                <audio ref={audioRef} controls autoPlay>
                  <source src={`src/content/music/${selectedCategory}/${currentSong}`} type="audio/mpeg" />
                  Your browser does not support the audio element.
                </audio>
                <div ref={waveformRef} className="waveform"></div>
              </div>
            )}
          </>
        )}
      </div>
      <Footer />
    </>
  );
};

export default Music;
