/* eslint-disable no-unused-vars */
import React from 'react';
import MarqueeWithBack from "../Component/MarqueeWithBack"; // Import the new component
import Banner from "../Component/Banner";
import Footer from "../Component/Footer";

const Kidszone = () => {
  return (
    <div>
      <MarqueeWithBack /> {/* Use the new MarqueeWithBackButton component */}
      <Banner />
      <Footer />
    </div>
  );
};

export default Kidszone;
