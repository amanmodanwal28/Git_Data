/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import MarqueeWithBack from "../Component/MarqueeWithBack"; 
import Banner from "../Component/Banner";
import Footer from "../Component/Footer";
import '../Css/Journey.css'; 

const Journey = () => {
  const [journeyData, setJourneyData] = useState(null);

  const fetchXMLData = async () => {
    try {
      const response = await fetch('/src/content/database/papis_info.xml'); // Adjust the path if necessary
      const text = await response.text();
      
      // Parse XML using DOMParser
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(text, "application/xml");
      
      // Extract data
      const speed = xmlDoc.getElementsByTagName("SPEED")[0].textContent;
      const adtns = xmlDoc.getElementsByTagName("ADTNS")[0].textContent;
      const lrs = xmlDoc.getElementsByTagName("LRS")[0].textContent;
      const ss = xmlDoc.getElementsByTagName("SS")[0].textContent;
      const cs = xmlDoc.getElementsByTagName("CS")[0].textContent;
      const ns = xmlDoc.getElementsByTagName("NS")[0].textContent;
      const ds = xmlDoc.getElementsByTagName("DS")[0].textContent;

      // Create new data object
      const newData = {
        speed,
        adtns,
        lrs,
        ss,
        cs,
        ns,
        ds,
      };

      // Update state only if there's a change
      if (JSON.stringify(journeyData) !== JSON.stringify(newData)) {
        setJourneyData(newData);
      }
    } catch (error) {
      console.error('Error fetching XML:', error);
    }
  };

  useEffect(() => {
    fetchXMLData(); // Fetch data initially

    // Set up polling
    const intervalId = setInterval(fetchXMLData, 1000); // Poll every 10 seconds

    // Clean up on unmount
    return () => clearInterval(intervalId);
  }, [journeyData]);

  return (
    <div>
      <MarqueeWithBack /> 
      <Banner />
      <div className="journey-info">
        {journeyData ? (
          <div className="journey-details">
            <h2 className="heading">Journey Information</h2>

            <table className="journey-table">
              <tbody>
                <tr>
                  <th>Source Station</th>
                  <td>{journeyData.ss}</td>
                </tr>
                <tr>
                  <th>Current Station</th>
                  <td>{journeyData.cs}</td>
                </tr>
                <tr>
                  <th>Next Station</th>
                  <td>{journeyData.ns}</td>
                </tr>
                <tr>
                  <th>Destination</th>
                  <td>{journeyData.ds}</td>
                </tr>
                <tr>
                  <th>Speed</th>
                  <td>{journeyData.speed} kmph</td>
                </tr>
                <tr>
                  <th>Approx Distance to Next Station</th>
                  <td>{journeyData.adtns} kms</td>
                </tr>
                <tr>
                  <th>Late Running Status</th>
                  <td>{journeyData.lrs}</td>
                </tr>
              </tbody>
            </table>

          </div>
        ) : (
          <p>Loading journey information...</p>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default Journey;
