/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import MarqueeWithBack from '../Component/MarqueeWithBack'
import Banner from '../Component/Banner' // Ensure this path is correct
import Footer from '../Component/Footer'
import '../Css/Tourist.css'
import useFetchDataWithIp from '../Api/useFetchDataWithIp'

const Tourist = () => {
  const { serverIp } = useFetchDataWithIp()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [fileList, setFileList] = useState([])
  const navigate = useNavigate()

  useEffect(() => {
    if (serverIp) {
      fetch(`${serverIp}/tourist`)
        .then((response) => response.json())
        .then((data) => {
          // Filter only files of type "file" and having image extensions
          const filteredFiles = data.filter(
            (file) =>
              file.type === 'file' &&
              (file.name.endsWith('.png') ||
                file.name.endsWith('.jpg') ||
                file.name.endsWith('.jpeg'))
          )
          setFileList(filteredFiles)
        })
        .catch((error) => console.error('Error fetching files:', error))
    }
  }, [serverIp])

  const handleNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === fileList.length - 1 ? 0 : prevIndex + 1
    )
  }
  const handlePrev = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? fileList.length - 1 : prevIndex - 1
    )
  }

  return (
    <>
      <MarqueeWithBack />
      <Banner /> {/* Ensure the Banner component renders here */}
      <h1 className="tourist-heading" onContextMenu={(e) => e.preventDefault()}>
        Tourist Places
      </h1>
      <div className="slider_container_img">
        <button className="arrow left-arrow" onClick={handlePrev}>
          &lt;
        </button>
        {fileList.length > 0 ? (
          <img
            alt={`Image ${currentIndex + 1}`}
            src={`${serverIp}/tourist/${fileList[currentIndex].name}`}
            className="slider-image"
          />
        ) : (
          <p>Loading images...</p>
        )}
        <button className="arrow right-arrow" onClick={handleNext}>
          &gt;
        </button>
      </div>
      <Footer />
    </>
  )
}
export default Tourist
