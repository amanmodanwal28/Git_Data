import dgram from 'dgram'
import express from 'express'
import { createServer } from 'http'
import { Server } from 'socket.io'

const udpServer = dgram.createSocket('udp4')
const app = express()
const server = createServer(app)
const io = new Server(server)

const PORT = 8001 // UDP port to receive data
const HOST = '127.0.0.1' // Loopback IP

// When the server receives a UDP message
udpServer.on('message', (msg, rinfo) => {
  console.log(`Received message: ${msg} from ${rinfo.address}:${rinfo.port}`)

  // Send the received message to all connected WebSocket clients
  io.emit('udpMessage', msg.toString())
})

// Bind the UDP server to the PORT and HOST
udpServer.bind(PORT, HOST)

// Set up the WebSocket connection
io.on('connection', (socket) => {
  console.log('WebSocket client connected')

  // Optionally handle disconnections
  socket.on('disconnect', () => {
    console.log('WebSocket client disconnected')
  })
})

// Start the HTTP/WebSocket server
server.listen(3000, () => {
  console.log('HTTP server listening on port 3000')
})

// Handle graceful shutdown
process.on('SIGINT', () => {
  udpServer.close(() => {
    console.log('UDP server closed')
    process.exit()
  })
})
