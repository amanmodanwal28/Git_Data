/* eslint-disable react/prop-types */
import { useEffect, useState } from 'react';
import '../Css/Popup.css'; // Importing CSS for the popup
import { io } from 'socket.io-client';
import useFetchDataWithIp from '../Api/useFetchDataWithIp';

const Popup = ({ pauseMedia, resumeMedia, isUserPaused }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { serverIp } = useFetchDataWithIp();

  useEffect(() => {
    // Set up the socket connection
    const socket = io(`${serverIp}`);

    // Handle WebSocket connection event
    socket.on('connection', () => {
      console.log('Connected to WebSocket server');
    });

    // Handle incoming UDP messages
    socket.on('udpMessage', (message) => {
      let UdpIncomingMessage = message.toLowerCase();
      console.log('Received UDP message:', UdpIncomingMessage);

      console.log(isUserPaused)
      if (UdpIncomingMessage.includes('open')) {
        // Only resume media playback if the user did not manually pause it
        if (!isUserPaused) {
          resumeMedia(); // Resume media playback
          setIsOpen(false); // Close the popup when 'open' message is received
        }else {
          pauseMedia(); // Resume media playback
            setIsOpen(false); // Close the popup when 'open' message is received

        }
      } else if (UdpIncomingMessage.includes('close')) {
        // Pause media playback
        pauseMedia(); // Pause media playback
        setIsOpen(true); // Show the popup when 'close' message is received
      }
    });

    // Clean up socket connection on component unmount
    return () => {
      socket.disconnect();
    };
  }, [serverIp, pauseMedia, resumeMedia, isUserPaused]); // Include isUserPaused in the dependency array

  // If popup is not open, render nothing
  if (!isOpen) return null;

  return (
    <div className="popup-overlay">
      <div className="popup-box">
        <h2>PA in Progress.....</h2>
      </div>
    </div>
  );
};

export default Popup;
