import React, { useEffect, useState } from 'react'
import { io } from 'socket.io-client'
import useFetchDataWithIp from '../Api/useFetchDataWithIp'

const UDPReceiver = () => {
  const [messages, setMessages] = useState([])
  const { serverIp } = useFetchDataWithIp()
  console.log(serverIp)
  useEffect(() => {
    const socket = io(`${serverIp}`)

    socket.on('connection', () => {
      console.log('Connected to WebSocket server')
    })

    socket.on('udpMessage', (message) => {
      console.log('Received UDP message:', message)
      setMessages((prevMessages) => [...prevMessages, message])
    })

    return () => {
      socket.disconnect()
    }
  }, [serverIp])

  return (
    <div>
      <h1>Received UDP Messages</h1>
      <ul>
        {messages.map((message, index) => (
          <li key={index}>{message}</li>
        ))}
      </ul>
    </div>
  )
}

export default UDPReceiver
