import React from 'react';
import {Heading} from '@chakra-ui/react'
const NotFound = () => {
    return (
        <div>
            <Heading>Product Not Found..</Heading>
        </div>
    );

}

export default NotFound